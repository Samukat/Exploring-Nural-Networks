// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    id("com.android.application") version "8.11.1" apply false
    id("org.jetbrains.kotlin.android") version "2.2.0" apply false
    kotlin("plugin.serialization") version "2.2.0"
    alias(libs.plugins.compose.compiler) apply false
    id("androidx.room") version "2.7.2" apply false
}

subprojects {
    configurations.configureEach {
        // F-Droid flags OpenCensus as a tracker when Gradle resolves Android test tooling.
        // AutoPie does not use it, so keep it out of all project dependency graphs.
        exclude(group = "io.opencensus")
        // Guava already provides ListenableFuture; AndroidX's standalone copy duplicates it.
        exclude(group = "com.google.guava", module = "listenablefuture")
    }
}
