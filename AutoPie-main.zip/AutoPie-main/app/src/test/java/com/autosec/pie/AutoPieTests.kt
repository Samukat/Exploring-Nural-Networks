package com.autopi


import android.app.Application
import android.os.Environment
import com.autopi.autopieApp.data.services.FakeJSONService
import com.autopi.autopieapp.data.CommandCreationModel
import com.autopi.autopieapp.data.CommandModel
import com.autopi.autopieapp.data.CommandType
import com.autopi.autopieapp.data.HomeCommandPreview
import com.autopi.autopieapp.data.homePreview
import com.autopi.autopieapp.data.preferences.AppPreferences
import com.autopi.autopieapp.data.services.ProcessManagerService
import com.autopi.autopieapp.domain.ViewModelError
import com.autopi.autopieapp.domain.model.CloudCommandModel
import com.autopi.autopieapp.domain.model.matchesSearch
import com.autopi.use_case.CreateCommand
import com.autopi.use_case.ChangeCommandDetails
import com.autopi.use_case.GetCommandDetails
import com.autopi.use_case.GetCommandsList
import com.autopi.use_case.GetRepoCommandsList
import com.autopi.use_case.InstallCloudCommand
import com.autopi.autopieapp.presentation.viewModels.isCloudCommandUpdateAvailable
import com.autopi.autopieapp.presentation.viewModels.filterUninstalledCloudCommands
import com.autopi.autopieapp.presentation.viewModels.keywordInstallScriptFor
import com.autopi.autopieapp.presentation.viewModels.matchesAnyCloudKeyword
import com.autopi.autopieapp.presentation.viewModels.sortCloudCommandsForCatalog
import com.autopi.autopieapp.data.services.MissingTermuxDependencies
import com.autopi.use_case.cloudManifestDocs
import com.autopi.use_case.cloudManifestToShareCommandJson
import com.autopi.use_case.CloudCommandDependencies
import com.autopi.use_case.CloudCommandInstallation
import com.autopi.use_case.CloudCommandInstallationState
import com.autopi.use_case.combinedCloudCommandInstallScript
import com.autopi.use_case.pendingCloudCommandInstallations
import com.google.gson.Gson
import io.mockk.every
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.mockkStatic
import io.mockk.mockk
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestCoroutineScheduler
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runBlockingTest
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TestWatcher
import org.junit.runner.Description
import org.koin.test.KoinTest
import timber.log.Timber
import java.io.File

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */


class CommandTests : KoinTest {
    @get:Rule
    val mainDispatcherRule = MainDispatcherRule()



    @Test
    fun `commands list initially contains two items`() = runTest {

        mockkStatic(Environment::class)

        val mockFile = File("/storage/emulated/0")
        every { Environment.getExternalStorageDirectory() } returns mockFile


        val jsonService = FakeJSONService()
        val getCommandsList = GetCommandsList(jsonService)

        mainDispatcherRule.scheduler.advanceUntilIdle()

        assertEquals(getCommandsList().size, 2)
    }

    @Test
    fun `incompatible command is skipped without hiding compatible commands`() = runTest {
        val jsonService = FakeJSONService()
        jsonService.writeCommandsConfig(
            """
            {
              "Compatible": {
                "path": "",
                "command": "echo ok",
                "exec": ""
              },
              "Requires newer app": {
                "path": "",
                "command": "echo new",
                "exec": "",
                "steps": {"unsupported": true}
              }
            }
            """.trimIndent()
        )
        var skippedCommands = emptyList<String>()

        val commands = GetCommandsList(jsonService).invoke { skippedCommands = it }
        val compatibleCommand = GetCommandDetails(jsonService)("Compatible")

        assertEquals(listOf("Compatible"), commands.map { it.name })
        assertEquals(listOf("Command: Requires newer app"), skippedCommands)
        assertEquals("echo ok", compatibleCommand.command)
    }

    @Test
    fun `repo catalog command id comes from object key`() = runTest {
        val jsonService = FakeJSONService()
        jsonService.writeCommandsConfig(
            """
            {
              "${'$'}schema": "schema/2026.6.1/catalog.schema.json",
              "commands": {
                "autopie.change-volume-on-mac": {
                  "addedAt": "2026-07-14T11:24:14Z",
                  "name": "Change Volume on Mac",
                  "namespace": "autopie",
                  "status": "stable",
                  "summary": "AutoPie command for Change Volume on Mac",
                  "tags": ["openssh"],
                  "type": "MANUAL",
                  "updatedAt": "2026-07-15T20:52:09Z",
                  "version": "1.0.0"
                }
              }
            }
            """.trimIndent()
        )

        val commands = GetRepoCommandsList(jsonService).invoke("unused")

        assertEquals(1, commands.size)
        assertEquals("autopie.change-volume-on-mac", commands.first().id)
        assertEquals("Change Volume on Mac", commands.first().name)
        assertEquals("AutoPie command for Change Volume on Mac", commands.first().summary)
        assertEquals(listOf("openssh"), commands.first().tags)
        assertEquals(CommandType.MANUAL, commands.first().type)
        assertEquals("2026-07-14T11:24:14Z", commands.first().addedAt)
        assertEquals("2026-07-15T20:52:09Z", commands.first().updatedAt)
        assertEquals("", commands.first().command)
    }

    @Test
    fun `manual runtime type is preserved in installed command json`() = runTest {
        val command = cloudManifestToShareCommandJson(
            """
            schemaVersion: "2026.6.1"
            version: "1.0.0"
            id: "autopie.change-volume-on-mac"
            namespace: "autopie"
            name: "Change Volume on Mac"
            commandSlug: "openssh"
            summary: "Set a Mac's output volume remotely over SSH."
            kind: "APP"
            tags: ["openssh"]
            runtime:
              path: ""
              type: "MANUAL"
            """.trimIndent()
        ).commandObject

        assertEquals("MANUAL", command.get("type").asString)
        assertEquals("openssh", command.get("exec").asString)
        assertFalse(command.has("installerVersion"))
        assertEquals(
            "Set a Mac's output volume remotely over SSH.",
            command.get("summary").asString
        )
    }

    @Test
    fun `cloud manifest converts to share command`() = runTest {
        val manifest = cloudManifestToShareCommandJson(
            """
            schemaVersion: "2026.6.1"
            version: "1.0.0"
            id: "autopie.change-volume-on-mac"
            namespace: "autopie"
            name: "Change Volume on Mac"
            commandSlug: "openssh"
            summary: "AutoPie command for Change Volume on Mac"
            type: "PACKAGE"
            tags: ["openssh"]
            runtime:
              path: "AutoSec/scripts"
              command: "sshpass -p \"${'$'}PASSWORD\" ssh \"${'$'}USER@${'$'}HOST\" \"osascript -e \\\"set volume output volume ${'$'}{VOLUME}\\\"\""
              flags: ["--show-loading-screen"]
              extras:
              - id: "574538"
                name: "VOLUME"
                type: "SLIDER"
                default: "0,50,100"
                description: "Slider to set volume."
                required: true
                flags: ["--int", "--realtime"]
              - id: "output"
                name: "OUTPUT_TYPE"
                type: "SELECTABLE"
                default: "pdf"
                description: "Output type."
                required: true
                selectableOptions:
                  PDF: "pdf"
                  Text: "txt"
            install:
              installerVersion: "2.1.0"
              dependencies:
                pkg: [ffmpeg]
                pip: [yt-dlp]
              script: "install.sh"
            """.trimIndent()
        )

        val command = manifest.commandObject
        val extras = command.getAsJsonArray("extras")
        val extra = extras.first().asJsonObject
        val selectableExtra = extras[1].asJsonObject

        assertEquals("Change Volume on Mac", manifest.commandKey)
        assertEquals(listOf("ffmpeg"), manifest.installDependencies.pkg)
        assertEquals(listOf("yt-dlp"), manifest.installDependencies.pip)
        assertEquals("install.sh", manifest.installScript)
        assertEquals("autopie.change-volume-on-mac", command.get("id").asString)
        assertEquals("1.0.0", command.get("version").asString)
        assertEquals("2.1.0", command.get("installerVersion").asString)
        assertEquals("SHARE", command.get("type").asString)
        assertEquals("AutoSec/scripts", command.get("path").asString)
        assertEquals("openssh", command.get("exec").asString)
        assertEquals("--show-loading-screen", command.getAsJsonArray("flags")[0].asString)
        assertEquals("VOLUME", extra.get("name").asString)
        assertEquals("--realtime", extra.getAsJsonArray("flags")[1].asString)
        assertEquals("pdf", selectableExtra.getAsJsonObject("selectableOptions").get("PDF").asString)
        assertEquals("txt", selectableExtra.getAsJsonObject("selectableOptions").get("Text").asString)
    }

    @Test
    fun `observer manifest keeps observer properties in commands config`() = runTest {
        val command = cloudManifestToShareCommandJson(
            """
            id: "autopie.watch-downloads"
            name: "Watch Downloads"
            type: "FILE_OBSERVER"
            runtime:
              path: "Download"
              command: "echo changed"
              selectors: [".*\\.mp4", ".*\\.mkv"]
            """.trimIndent()
        ).commandObject

        assertEquals("FILE_OBSERVER", command.get("type").asString)
        assertEquals(".*\\.mp4", command.getAsJsonArray("selectors")[0].asString)
        assertFalse(command.has("summary"))
    }

    @Test
    fun `cron manifest keeps cron properties in commands config`() = runTest {
        val command = cloudManifestToShareCommandJson(
            """
            id: "autopie.hourly-sync"
            name: "Hourly Sync"
            type: "CRON"
            runtime:
              command: "rsync source target"
              cronInterval: "1h"
            """.trimIndent()
        ).commandObject

        assertEquals("CRON", command.get("type").asString)
        assertEquals("1h", command.get("cronInterval").asString)
    }

    @Test
    fun `package manifest uses runtime command type`() = runTest {
        val command = cloudManifestToShareCommandJson(
            """
            schemaVersion: "2026.6.1"
            version: "1.0.0"
            id: "autopie.github-repo-monitor"
            namespace: "autopie"
            name: "GitHub Repo Monitor"
            commandSlug: ""
            summary: "A 15-minute GitHub repository monitor cron designed for display as an Android widget."
            type: "PACKAGE"
            tags: ["python", "github", "cron", "widget"]
            runtime:
              path: ""
              type: "CRON"
              cronInterval: "15m"
              command: |-
                echo monitor
            """.trimIndent()
        ).commandObject

        assertEquals("CRON", command.get("type").asString)
        assertEquals("15m", command.get("cronInterval").asString)
        assertEquals("echo monitor", command.get("command").asString)
    }

    @Test
    fun `cloud command update is available when catalog version is newer`() = runTest {
        assertEquals(true, isCloudCommandUpdateAvailable("1.1.0", "1.0.0"))
        assertEquals(false, isCloudCommandUpdateAvailable("1.0.0", "1.0.0"))
        assertEquals(false, isCloudCommandUpdateAvailable("1.0.0", "1.1.0"))
        assertEquals(true, isCloudCommandUpdateAvailable("1.0.0", ""))
    }

    @Test
    fun `cloud commands with updates are sorted first`() = runTest {
        val commands = listOf(
            CloudCommandModel(id = "autopie.z-current", name = "Z Current", version = "1.0.0"),
            CloudCommandModel(id = "autopie.a-update", name = "A Update", version = "1.1.0"),
            CloudCommandModel(id = "autopie.b-new", name = "B New", version = "1.0.0")
        )

        val sorted = sortCloudCommandsForCatalog(
            commands,
            mapOf(
                "autopie.z-current" to "1.0.0",
                "autopie.a-update" to "1.0.0"
            )
        )

        assertEquals(listOf("autopie.a-update", "autopie.b-new", "autopie.z-current"), sorted.map { it.id })
    }

    @Test
    fun `home catalog search excludes commands that are already installed`() = runTest {
        val commands = listOf(
            CloudCommandModel(id = "autopie.installed", name = "Installed"),
            CloudCommandModel(id = "autopie.available", name = "Available")
        )

        val availableCommands = filterUninstalledCloudCommands(
            commands,
            installedVersions = mapOf("autopie.installed" to "1.0.0")
        )

        assertEquals(listOf("autopie.available"), availableCommands.map { it.id })
    }

    @Test
    fun `cloud commands are sorted by updated timestamp with added timestamp fallback`() = runTest {
        val commands = listOf(
            CloudCommandModel(
                id = "autopie.updated-old",
                name = "Updated Old",
                addedAt = "2026-09-10T00:00:00Z",
                updatedAt = "2026-09-11T00:00:00Z"
            ),
            CloudCommandModel(
                id = "autopie.added-fallback",
                name = "Added Fallback",
                addedAt = "2026-09-13T00:00:00Z"
            ),
            CloudCommandModel(
                id = "autopie.updated-new",
                name = "Updated New",
                addedAt = "2026-09-09T00:00:00Z",
                updatedAt = "2026-09-14T00:00:00Z"
            ),
            CloudCommandModel(
                id = "autopie.invalid-updated",
                name = "Invalid Updated",
                addedAt = "2026-09-12T00:00:00Z",
                updatedAt = "unavailable"
            ),
            CloudCommandModel(id = "autopie.no-timestamp", name = "No Timestamp")
        )

        val sorted = sortCloudCommandsForCatalog(commands, emptyMap())

        assertEquals(
            listOf(
                "autopie.updated-new",
                "autopie.added-fallback",
                "autopie.invalid-updated",
                "autopie.updated-old",
                "autopie.no-timestamp"
            ),
            sorted.map { it.id }
        )
    }

    @Test
    fun `cloud command keyword matching checks catalog metadata`() = runTest {
        val ffmpegCommand = CloudCommandModel(
            id = "autopie.extract-audio",
            name = "Extract Audio",
            summary = "Convert media files",
            tags = listOf("ffmpeg")
        )
        val imageMagickCommand = CloudCommandModel(
            id = "autopie.resize-image",
            name = "Resize Image",
            summary = "ImageMagick powered resize",
            tags = listOf("images")
        )
        val unrelatedCommand = CloudCommandModel(
            id = "autopie.sync-folder",
            name = "Sync Folder",
            tags = listOf("rsync")
        )

        val selectedKeywords = listOf("ffmpeg", "imagemagick")

        assertEquals(true, ffmpegCommand.matchesAnyCloudKeyword(selectedKeywords))
        assertEquals(true, imageMagickCommand.matchesAnyCloudKeyword(selectedKeywords))
        assertEquals(false, unrelatedCommand.matchesAnyCloudKeyword(selectedKeywords))
    }

    @Test
    fun `cloud command search matches every command type`() = runTest {
        CommandType.entries.forEach { type ->
            val command = CloudCommandModel(
                id = "autopie.type-search",
                type = type,
                name = "Type Search"
            )

            assertTrue(command.matchesSearch(type.name.lowercase()))
        }
    }

    @Test
    fun `home command preview supports summary and command modes`() = runTest {
        val command = CommandModel(summary = "Friendly summary", command = "echo fallback")

        assertEquals(HomeCommandPreview.SUMMARY, HomeCommandPreview.fromPreference(""))
        assertEquals(HomeCommandPreview.COMMAND, HomeCommandPreview.fromPreference("command"))
        assertEquals(
            "Friendly summary",
            command.homePreview(HomeCommandPreview.SUMMARY)
        )
        assertEquals(
            "echo fallback",
            command.homePreview(HomeCommandPreview.COMMAND)
        )
        assertEquals(
            "echo fallback",
            CommandModel(summary = "", command = "\necho fallback\n")
                .homePreview(HomeCommandPreview.SUMMARY)
        )
    }

    @Test
    fun `keyword install script uses fixed commands once`() = runTest {
        val installScript = keywordInstallScriptFor(listOf("ffmpeg", "yt-dlp", "ffmpeg", "unknown"))

        assertTrue(installScript.contains("dpkg -s \"${'$'}package\""))
        assertTrue(installScript.contains("pip show \"${'$'}package\""))
        assertTrue(installScript.contains("pkg install -y \"${'$'}package\""))
        assertTrue(installScript.contains("pip install \"${'$'}package\""))
        assertEquals(1, "autopie_pkg_install_once ffmpeg".toRegex().findAll(installScript).count())
        assertEquals(1, "autopie_pip_install_once yt-dlp".toRegex().findAll(installScript).count())
        assertFalse(installScript.contains("imagemagick"))
        assertFalse(installScript.contains("unknown"))
    }

    @Test
    fun `cloud install puts manifest dependencies before optional script`() = runTest {
        val installCommand = combinedCloudCommandInstallScript(
            listOf(
                CloudCommandInstallation(
                    commandName = "Download video",
                    dependencies = CloudCommandDependencies(
                        pkg = listOf("ffmpeg"),
                        pip = listOf("yt-dlp")
                    ),
                    script = "echo custom setup"
                )
            )
        )

        val pkgInstall = "pkg install -y 'ffmpeg'"
        val pipInstall = "pip install 'yt-dlp'"
        val customInstall = "echo custom setup"
        assertTrue(installCommand.indexOf(pkgInstall) < installCommand.indexOf(pipInstall))
        assertTrue(installCommand.indexOf(pipInstall) < installCommand.indexOf(customInstall))
    }

    @Test
    fun `cloud install falls back to script when dependencies are absent`() = runTest {
        val installCommand = combinedCloudCommandInstallScript(
            listOf(
                CloudCommandInstallation(
                    commandName = "Legacy command",
                    script = "echo legacy setup"
                )
            )
        )

        assertTrue(installCommand.contains("echo legacy setup"))
        assertFalse(installCommand.contains("pkg install"))
        assertFalse(installCommand.contains("pip install"))
    }

    @Test
    fun `cloud install keeps only missing dependencies and skips unchanged installer`() = runTest {
        val pendingInstallations = pendingCloudCommandInstallations(
            states = listOf(
                CloudCommandInstallationState(
                    installation = CloudCommandInstallation(
                        commandName = "Download video",
                        dependencies = CloudCommandDependencies(
                            pkg = listOf("ffmpeg", "aria2"),
                            pip = listOf("yt-dlp")
                        ),
                        script = "echo custom setup",
                        installerVersion = "2.1.0"
                    ),
                    installedInstallerVersion = "2.1.0"
                )
            ),
            missingDependencies = MissingTermuxDependencies(pkg = listOf("aria2"))
        )

        assertEquals(1, pendingInstallations.size)
        assertEquals(listOf("aria2"), pendingInstallations.single().dependencies.pkg)
        assertTrue(pendingInstallations.single().dependencies.pip.isEmpty())
        assertEquals(null, pendingInstallations.single().script)
    }

    @Test
    fun `cloud install is skipped when dependencies and installer are current`() = runTest {
        val pendingInstallations = pendingCloudCommandInstallations(
            states = listOf(
                CloudCommandInstallationState(
                    installation = CloudCommandInstallation(
                        commandName = "Download video",
                        dependencies = CloudCommandDependencies(pkg = listOf("ffmpeg")),
                        script = "echo custom setup",
                        installerVersion = "2.1.0"
                    ),
                    installedInstallerVersion = "2.1.0"
                )
            ),
            missingDependencies = MissingTermuxDependencies()
        )

        assertTrue(pendingInstallations.isEmpty())
    }

    @Test
    fun `cloud install does not open Termux when every dependency exists`() = runTest {
        val processManagerService = mockk<ProcessManagerService>(relaxed = true)
        coEvery {
            processManagerService.findMissingTermuxDependencies(any(), any())
        } returns MissingTermuxDependencies()
        val appPreferences = mockk<AppPreferences>(relaxed = true)
        every { appPreferences.getStringSync(any()) } returns ""
        val installer = InstallCloudCommand(
            jsonService = FakeJSONService(),
            processManagerService = processManagerService,
            application = mockk<Application>(relaxed = true),
            appPreferences = appPreferences
        )

        installer(
            commandId = "autopie.dependencies-current",
            manifestYaml =
                """
                id: "autopie.dependencies-current"
                name: "Dependencies current"
                runtime:
                  command: "echo ready"
                install:
                  installerVersion: "2.1.0"
                  dependencies:
                    pkg: [ffmpeg]
                    pip: [yt-dlp]
                  script: "install.sh"
                """.trimIndent()
        )

        coVerify(exactly = 0) {
            processManagerService.runCommandInTermuxShell(
                commandObject = any(),
                exec = any(),
                command = any(),
                cwd = any(),
                commandExtraInputs = any(),
                rawInput = any(),
                processId = any(),
                jobType = any(),
                usePython = any(),
                isShellScript = any()
            )
        }
    }

    @Test
    fun `legacy or changed installer still runs when dependencies are current`() = runTest {
        val pendingInstallations = pendingCloudCommandInstallations(
            states = listOf(
                CloudCommandInstallationState(
                    installation = CloudCommandInstallation(
                        commandName = "Changed installer",
                        script = "echo changed",
                        installerVersion = "2.1.0"
                    ),
                    installedInstallerVersion = "2.0.0"
                ),
                CloudCommandInstallationState(
                    installation = CloudCommandInstallation(
                        commandName = "Legacy installer",
                        script = "echo legacy"
                    ),
                    installedInstallerVersion = null
                )
            ),
            missingDependencies = MissingTermuxDependencies()
        )

        assertEquals(listOf("echo changed", "echo legacy"), pendingInstallations.map { it.script })
    }

    @Test
    fun `cloud manifest exposes documentation paths`() = runTest {
        val docs = cloudManifestDocs(
            """
            schemaVersion: "2026.6.1"
            id: "autopie.change-volume-on-mac"
            name: "Change Volume on Mac"
            runtime:
              path: "AutoSec/scripts"
              command: "echo ok"
            docs:
              readme: "README.md"
              changelog: "CHANGELOG.md"
            """.trimIndent()
        )

        assertEquals("README.md", docs.readme)
        assertEquals("CHANGELOG.md", docs.changelog)
    }

    @Test
    fun `cloud multistage manifest converts steps to share command`() = runTest {
        val manifest = cloudManifestToShareCommandJson(
            """
            schemaVersion: "2026.6.1"
            version: "1.0.0"
            id: "autopie.change-volume-on-mac-autofetch"
            namespace: "autopie"
            name: "Change Volume on Mac - AutoFetch"
            commandSlug: "change-volume-on-mac-autofetch"
            summary: "AutoPie command for Change Volume on Mac - AutoFetch"
            type: "PACKAGE"
            tags: ["openssh"]
            runtime:
              multiStage: true
              steps:
              - id: "inspect"
                path: "AutoSec/scripts"
                commandSlug: "openssh"
                command: "export SLIDER_OPTIONS=0,50,100"
              - id: "download"
                path: "AutoSec/scripts"
                commandSlug: "openssh"
                command: "sshpass -p \"${'$'}PASSWORD\" ssh \"${'$'}USER@${'$'}HOST\""
                flags: ["--show-loading-screen"]
                extras:
                - id: "574538"
                  name: "VOLUME"
                  type: "SLIDER"
                  default: "${'$'}${'$'}SLIDER_OPTIONS"
                  description: "Slider to set volume."
                  required: true
                  flags: ["--int", "--realtime"]
                - id: "output"
                  name: "OUTPUT_TYPE"
                  type: "SELECTABLE"
                  default: "pdf"
                  description: "Output type."
                  selectableOptions:
                    PDF: "pdf"
                    Text: "txt"
                  visibleWhen:
                    all:
                    - extraId: "574538"
                      notEquals: "0"
                    - extraId: "mode"
                      equals: "document"
              - id: "notify"
                commandId: "autopie.notify-complete"
            install:
              script: "install.sh"
            """.trimIndent()
        )

        val command = manifest.commandObject
        val steps = command.getAsJsonArray("steps")
        val secondStep = steps[1].asJsonObject

        assertEquals("Change Volume on Mac - AutoFetch", manifest.commandKey)
        assertEquals(true, command.get("multiStage").asBoolean)
        assertEquals("openssh", command.get("exec").asString)
        assertEquals("inspect", steps[0].asJsonObject.get("id").asString)
        assertEquals("download", secondStep.get("id").asString)
        assertEquals("notify", steps[2].asJsonObject.get("id").asString)
        assertEquals(
            "autopie.notify-complete",
            steps[2].asJsonObject.get("commandId").asString
        )
        assertEquals("--show-loading-screen", secondStep.getAsJsonArray("flags")[0].asString)
        assertEquals("VOLUME", secondStep.getAsJsonArray("extras")[0].asJsonObject.get("name").asString)
        assertEquals(
            "574538",
            secondStep.getAsJsonArray("extras")[1]
                .asJsonObject
                .getAsJsonObject("visibleWhen")
                .getAsJsonArray("all")[0]
                .asJsonObject
                .get("extraId")
                .asString
        )
        assertFalse(secondStep.getAsJsonArray("extras")[1].asJsonObject.has("required"))
        assertEquals(
            "pdf",
            secondStep.getAsJsonArray("extras")[1]
                .asJsonObject
                .getAsJsonObject("selectableOptions")
                .get("PDF")
                .asString
        )

        val parsedCommand = Gson().fromJson(command, CommandModel::class.java)
        val parsedSelectableExtra = parsedCommand.steps[1].extras!![1]
        assertTrue(parsedSelectableExtra.required)
        assertEquals(
            "574538",
            parsedSelectableExtra.visibleWhen?.all?.first()?.extraId
        )
        assertEquals("autopie.notify-complete", parsedCommand.steps[2].commandId)
    }

    @Test
    fun `adding a command makes it 3`() = runTest {

        mockkStatic(Environment::class)

        val mockFile = File("/storage/emulated/0")
        every { Environment.getExternalStorageDirectory() } returns mockFile


        val jsonService = FakeJSONService()
        val createCommand = CreateCommand(jsonService)

        val newCommand = CommandCreationModel(
            selectedCommandType = "SHARE",
            commandName = "Create Plumbus",
            directory = "",
            command = "plumb --create",
            isValidCommand = true,
            exec = "plumbus",
            commandExtras = emptyList(),
            selectors = "",
            cronInterval = ""
        )

        createCommand(newCommand)

        val created = jsonService.readCommandsConfig()!!.getAsJsonObject("Create Plumbus")
        assertEquals("local.create-plumbus", created.get("id").asString)

        val getCommandsList = GetCommandsList(jsonService)


        assertEquals(getCommandsList().size, 3)
    }

    @Test
    fun `raw json adds commands keyed by name`() = runTest {
        val jsonService = FakeJSONService()
        val createCommand = CreateCommand(jsonService)

        createCommand.fromRawJson(
            """
            {
              "First raw command": {"command": "echo first", "type": "SHARE"},
              "Second raw command": {}
            }
            """.trimIndent()
        )

        val commands = jsonService.readCommandsConfig()!!
        assertEquals("echo first", commands.getAsJsonObject("First raw command").get("command").asString)
        assertTrue(commands.get("Second raw command").isJsonObject)
        assertEquals(4, commands.size())
    }

    @Test
    fun `raw json replaces an existing command with the same key`() = runTest {
        val jsonService = FakeJSONService()
        val createCommand = CreateCommand(jsonService)

        createCommand.fromRawJson(
            """{"Extract Audio": {"command": "echo replacement", "type": "SHARE"}}"""
        )

        val command = jsonService.readCommandsConfig()!!.getAsJsonObject("Extract Audio")
        assertEquals("echo replacement", command.get("command").asString)
        assertEquals(2, jsonService.readCommandsConfig()!!.size())
    }

    @Test
    fun `raw json rejects command values that are not objects without writing`() = runTest {
        val jsonService = FakeJSONService()
        val original = jsonService.getRawStorageContent()
        val createCommand = CreateCommand(jsonService)

        assertThrows(ViewModelError.InvalidRawCommandJson::class.java) {
            runBlocking { createCommand.fromRawJson("""{"Broken": "echo nope"}""") }
        }

        assertEquals(original, jsonService.getRawStorageContent())
    }

    @Test
    fun `raw editor replaces only the selected command object`() = runTest {
        val jsonService = FakeJSONService()
        val changeCommandDetails = ChangeCommandDetails(jsonService)

        changeCommandDetails.fromRawJson(
            "Extract Audio",
            """{"Renamed command": {"command": "echo edited", "customProperty": {"enabled": true}}}"""
        )

        val commands = jsonService.readCommandsConfig()!!
        val edited = commands.getAsJsonObject("Renamed command")
        assertEquals("echo edited", edited.get("command").asString)
        assertTrue(edited.getAsJsonObject("customProperty").get("enabled").asBoolean)
        assertFalse(commands.has("Extract Audio"))
        assertTrue(commands.has("RSYNC Sync Folder"))
    }

    @Test
    fun `raw editor rejects a non-object without changing the command`() = runTest {
        val jsonService = FakeJSONService()
        val original = jsonService.getRawStorageContent()
        val changeCommandDetails = ChangeCommandDetails(jsonService)

        assertThrows(ViewModelError.InvalidRawCommandJson::class.java) {
            runBlocking { changeCommandDetails.fromRawJson("Extract Audio", "[]") }
        }

        assertEquals(original, jsonService.getRawStorageContent())
    }

    @Test
    fun `get a command - success`() = runTest {

        val jsonService = FakeJSONService()
        val getCommand = GetCommandDetails(jsonService)

        val command = getCommand("RSYNC Sync Folder")

        //assertEquals("rsync",command.get("exec").asString)


    }

    @Test
    fun `get a non existent command`() = runTest {

        val jsonService = FakeJSONService()
        val getCommand = GetCommandDetails(jsonService)


        assertThrows(ViewModelError.CommandNotFound::class.java){
            runBlocking {
                getCommand("non existent command")
            }
        }
    }
}

class MainDispatcherRule : TestWatcher() {
    val scheduler = TestCoroutineScheduler()
    val testDispatcher = StandardTestDispatcher(scheduler)

    @OptIn(ExperimentalCoroutinesApi::class)
    override fun starting(description: Description) {
        Dispatchers.setMain(testDispatcher)
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    override fun finished(description: Description) {
        Dispatchers.resetMain()
    }
}
