package com.autopi.autopieApp.data

import com.autopi.autopieapp.data.CommandExtra
import com.autopi.autopieapp.data.CommandFlags
import com.autopi.autopieapp.data.ExtraFlags
import com.autopi.autopieapp.data.flagValue
import com.autopi.autopieapp.data.hasFlag
import com.autopi.autopieapp.data.isMultilineText
import com.autopi.autopieapp.data.isSecretExtra
import com.autopi.autopieapp.data.withFlag
import com.google.gson.Gson
import com.google.gson.JsonParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CommandExtraFlagsTest {
    @Test
    fun `extra flags deserialize from string array`() {
        val extra = Gson().fromJson(
            """{"id":"1","flags":["--file-picker","--password"]}""",
            CommandExtra::class.java
        )

        assertEquals(listOf("--file-picker", "--password"), extra.flags)
    }

    @Test
    fun `missing flags remain compatible`() {
        val extra = Gson().fromJson("""{"id":"1"}""", CommandExtra::class.java)

        assertTrue(extra.flags.orEmpty().isEmpty())
    }

    @Test
    fun `password-like extra names are treated as secrets without flags`() {
        assertTrue(CommandExtra(id = "1", name = "PASSWORD").isSecretExtra())
        assertTrue(CommandExtra(id = "2", name = "api_secret").isSecretExtra())
        assertTrue(CommandExtra(id = "3", name = "ssh_passwd").isSecretExtra())
        assertFalse(CommandExtra(id = "4", name = "USERNAME").isSecretExtra())
    }

    @Test
    fun `missing optional extra fields use app defaults`() {
        val extra = Gson().fromJson("""{"id":"1","type":"STRING"}""", CommandExtra::class.java)

        assertTrue(extra.defaultBoolean)
        assertTrue(extra.required)
        assertTrue(extra.selectableOptions.isEmpty())
    }

    @Test
    fun `selectable options still deserialize from array`() {
        val extra = Gson().fromJson(
            """{"id":"1","type":"SELECTABLE","selectableOptions":["one","two"]}""",
            CommandExtra::class.java
        )

        assertEquals(
            linkedMapOf("one" to "one", "two" to "two"),
            extra.selectableOptions
        )
    }

    @Test
    fun `selectable options still serialize as object`() {
        val json = Gson().toJson(
            CommandExtra(
                id = "1",
                type = "SELECTABLE",
                selectableOptions = linkedMapOf("Friendly label" to "--raw-value")
            )
        )

        val selectableOptions = JsonParser.parseString(json)
            .asJsonObject
            .getAsJsonObject("selectableOptions")

        assertEquals("--raw-value", selectableOptions["Friendly label"].asString)
    }

    @Test
    fun `internal config flag is deserialized and detected`() {
        val extra = Gson().fromJson(
            """{"id":"internal","flags":["--internal-config"]}""",
            CommandExtra::class.java
        )

        assertTrue(extra.flags.hasFlag(ExtraFlags.INTERNAL_CONFIG))
    }

    @Test
    fun `general flag methods parse names and quoted values`() {
        val flags = listOf("--file-picker", "--mime-type=\"application/pdf\"")

        assertTrue(flags.hasFlag(ExtraFlags.FILE_PICKER))
        assertTrue(flags.hasFlag(ExtraFlags.MIME_TYPE))
        assertEquals("application/pdf", flags.flagValue(ExtraFlags.MIME_TYPE))
        assertFalse(flags.hasFlag(ExtraFlags.PASSWORD))
    }

    @Test
    fun `missing flag value returns null`() {
        assertNull(listOf("--file-picker").flagValue(ExtraFlags.MIME_TYPE))
        assertNull(listOf("--mime-type").flagValue(ExtraFlags.MIME_TYPE))
    }

    @Test
    fun `int flag is detected`() {
        assertTrue(listOf("--int").hasFlag(ExtraFlags.INT))
        assertFalse(emptyList<String>().hasFlag(ExtraFlags.INT))
    }

    @Test
    fun `folder picker flag is detected`() {
        assertTrue(listOf("--folder-picker").hasFlag(ExtraFlags.FOLDER_PICKER))
        assertFalse(emptyList<String>().hasFlag(ExtraFlags.FOLDER_PICKER))
    }

    @Test
    fun `extra size flags are detected`() {
        val flags = listOf("--small", "--large")

        assertTrue(flags.hasFlag(ExtraFlags.SMALL))
        assertTrue(flags.hasFlag(ExtraFlags.LARGE))
    }

    @Test
    fun `realtime extra flag is detected`() {
        assertTrue(listOf("--realtime").hasFlag(ExtraFlags.REALTIME))
        assertFalse(emptyList<String>().hasFlag(ExtraFlags.REALTIME))
    }

    @Test
    fun `multiline string and text alias use multiline presentation`() {
        assertTrue(
            CommandExtra(
                id = "prompt",
                type = "STRING",
                flags = listOf("--multiline")
            ).isMultilineText()
        )
        assertTrue(CommandExtra(id = "prompt", type = "TEXT").isMultilineText())
        assertFalse(CommandExtra(id = "prompt", type = "STRING").isMultilineText())
    }

    @Test
    fun `multiline flag can be normalized without changing other flags`() {
        val flags = listOf("--secret").withFlag(ExtraFlags.MULTILINE, enabled = true)

        assertEquals(listOf("--secret", "--multiline"), flags)
        assertEquals(listOf("--secret"), flags.withFlag(ExtraFlags.MULTILINE, enabled = false))
    }

    @Test
    fun `loading screen command flag is detected`() {
        assertTrue(listOf("--show-loading-screen").hasFlag(CommandFlags.SHOW_LOADING_SCREEN))
        assertFalse(emptyList<String>().hasFlag(CommandFlags.SHOW_LOADING_SCREEN))
    }

    @Test
    fun `small loading screen command flag is detected`() {
        assertTrue(listOf("--show-loading-screen-small").hasFlag(CommandFlags.SHOW_LOADING_SCREEN_SMALL))
        assertFalse(emptyList<String>().hasFlag(CommandFlags.SHOW_LOADING_SCREEN_SMALL))
    }

    @Test
    fun `realtime command flag is detected`() {
        assertTrue(listOf("--realtime").hasFlag(CommandFlags.REALTIME))
        assertFalse(emptyList<String>().hasFlag(CommandFlags.REALTIME))
    }
}
