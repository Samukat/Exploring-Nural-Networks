package com.autopi.autopieApp.data.services

import com.autopi.autopieapp.data.services.JsonService
import com.autopi.autopieapp.domain.ViewModelError
import com.google.gson.Gson
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import timber.log.Timber

class FakeJSONService : JsonService {
    private var inMemoryStorage = mutableMapOf<String, String>()

    private val COMMANDS_KEY = "commands.json"

    init {
        inMemoryStorage[COMMANDS_KEY] = """
                {
                    "Extract Audio": {
                        "path": "",
                        "exec": "ffmpeg",
                        "command": "",
                        "deleteSourceFile": false,
                        "extras": [
                            {
                                "default": "195K",
                                "defaultBoolean": true,
                                "description": "A value from 56K to 320K.\nLarger means better quality.",
                                "id": "715336",
                                "name": "BITRATE",
                                "selectableOptions": [
                                    ""
                                ],
                                "type": "STRING"
                            }
                        ]
                    },
                    "RSYNC Sync Folder": {
                        "path": "",
                        "exec": "rsync",
                        "command": "",
                        "deleteSourceFile": false,
                        "extras": [
                            {
                                "default": "195K",
                                "defaultBoolean": true,
                                "description": "A value from 56K to 320K.\nLarger means better quality.",
                                "id": "715336",
                                "name": "BITRATE",
                                "selectableOptions": [
                                    ""
                                ],
                                "type": "STRING"
                            }
                        ]
                    }
                }
            """.trimIndent()
    }

    override fun readCommandsConfig(): JsonObject? {


//        if (!mainViewModel.storageManagerPermissionGranted) {
//            return null
//        }

        try {
            val jsonString = inMemoryStorage[COMMANDS_KEY] ?: return null

            Timber.d("Json str: ${jsonString}")

            // Parse the JSON string
            val gson = Gson()
            val dataObject = gson.fromJson(jsonString, JsonElement::class.java)

            if(dataObject == null) {
                Timber.d("Commands config not available")
                throw ViewModelError.CommandConfigUnavailable
            }

            if (!dataObject.isJsonObject) {
                Timber.d("Commands config is not valid json")

                throw ViewModelError.InvalidCommandConfig
            }

            Timber.d("Json Obj: ${dataObject.asJsonObject}")

            return dataObject.asJsonObject
        } catch (e: Exception) {
            Timber.e(e)
            throw e

        }
    }

    override fun writeCommandsConfig(jsonString: String) {
        try {
            inMemoryStorage[COMMANDS_KEY] = jsonString
        } catch (e: Exception) {
            Timber.e(e)
        }
    }

    override fun readRepoList(path: String): JsonObject? {
        return readCommandsConfig()
    }

    // Helper method for tests to clear storage
    fun clearStorage() {
        inMemoryStorage.clear()
    }

    // Helper method for tests to get raw storage content
    fun getRawStorageContent(key: String = COMMANDS_KEY): String? {
        return inMemoryStorage[key]
    }

}
