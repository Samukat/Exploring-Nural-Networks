package com.autopi.autopieapp.domain.model

import com.autopi.autopieapp.data.CommandType
import kotlinx.serialization.Serializable


@Serializable
data class GenericResponseDTO<T>(
    val ok: Boolean,
    val data: T,
)

@Serializable
data class CloudCommandsListDto(
    val kind: String,
    val items: List<CloudCommandModel>,
    val cursor: String,
    val hasNext: Boolean
)

@Serializable
data class CloudCommandModel(
    override val id: String = "",
    override val type: CommandType = CommandType.SHARE,
    override val name: String = "",
    override val directory: String = "",
    override val command: String = "",
    override val packageUniqueName: String = "",
    override val installationScript: String = "",
    override val description: String = "", //Link to MD file.
    override val extrasRequired : Boolean? = false,
    override val extras: List<CloudCommandExtra>? = null,
    val namespace: String = "",
    val status: String = "",
    val summary: String = "",
    val tags: List<String> = emptyList(),
    val version: String = "",
    val addedAt: String? = null,
    val updatedAt: String? = null
) : CloudCommandInterface

fun CloudCommandModel.matchesSearch(query: String): Boolean {
    if (query.isBlank()) return true

    return id.contains(query, ignoreCase = true) ||
        type.name.contains(query, ignoreCase = true) ||
        name.contains(query, ignoreCase = true) ||
        namespace.contains(query, ignoreCase = true) ||
        status.contains(query, ignoreCase = true) ||
        summary.contains(query, ignoreCase = true) ||
        version.contains(query, ignoreCase = true) ||
        tags.any { tag -> tag.contains(query, ignoreCase = true) }
}



interface CloudCommandInterface {
    val id: String
    val type: CommandType
    val name: String
    val directory: String
    val command: String
    val description: String?
    val packageUniqueName: String
    val installationScript: String?
    val extrasRequired : Boolean?
    val extras: List<CloudCommandExtra>?
}

@Serializable
data class CloudCommandExtra(
    val id: String,
    val name: String = "",
    val type: String = "",
    val default: String = "",
    val description: String = "",
    val defaultBoolean: Boolean = true,
    val selectableOptions: List<String> = emptyList()
)
