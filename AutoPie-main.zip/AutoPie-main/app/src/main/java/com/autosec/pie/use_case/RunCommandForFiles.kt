package com.autopi.use_case

import com.autopi.autopieapp.data.CommandExtraInput
import com.autopi.autopieapp.data.CommandModel
import com.autopi.autopieapp.data.CommandResult
import com.autopi.autopieapp.data.ExecAndCommand
import com.autopi.autopieapp.data.ExecType
import com.autopi.autopieapp.data.InputParsedData
import com.autopi.autopieapp.data.JobType
import com.autopi.autopieapp.data.services.ProcessManagerService
import com.autopi.utils.Utils
import com.autopi.utils.extractHttpUrls
import com.autopi.utils.toCommandResult
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import timber.log.Timber
import java.io.File
import kotlin.io.path.Path
import kotlin.io.path.absolutePathString
import kotlin.io.path.extension
import kotlin.io.path.nameWithoutExtension

class RunCommandForFiles(private val processManagerService: ProcessManagerService){
    operator fun invoke(
        item: CommandModel,
        inputText: String?,
        inputFiles: List<String>,
        commandExtraInputs: List<CommandExtraInput> = emptyList(),
        processId: Int
    ) : Flow<CommandResult> {
        Timber.d("runCommandForFiles")


        return flow{
            val currentItems = inputFiles

            if (item.command.contains("INPUT_FILES")) {

                Timber.d("Multiple Input files detected")


                val replacedString = item.command


                Timber.d("Replaced String $replacedString")

                val execFilePath = processManagerService.getAutoPiePackagePath(item.exec)
                val path = processManagerService.getCommandWorkingDirectory(item.path)


                val (_,fullExecPath, resultCommand) = when{
                    File(item.exec).isAbsolute -> {
                        Timber.d("Using package absolute path")
                        ExecAndCommand( ExecType.ABSOLUTE_PATH,item.exec,"\"${item.command}\"")
                    }
                    File(execFilePath).isFile -> {
                        Timber.d("Using autopie package")
                        //For packages installed inside autosec/bin
                        ExecAndCommand( ExecType.AUTOPIE_PACKAGE,execFilePath,"\"${item.command}\"")
                    }
                    else -> {
                        //Base case fallback to terminals installed packages such as busybox packages.
                        Timber.d("Using shell installed program")
                        ExecAndCommand( ExecType.SHELL_INSTALLED,item.exec, item.command)
                    }
                }

                val isShellScript = Utils.isShellScript(File(fullExecPath))
                val usePython = Utils.isZipFile(File(fullExecPath)) || Utils.isPythonScript(item.command)

//                val inputFiles = if(usePython){
//                    currentItems.joinToString(" "){"'${it}'"}.replace("''","'").replace("'", "\'")
//                }else{
//                    currentItems.joinToString(" ")
//                }

                val inputFilesString = currentItems.joinToString("\n")

                val parsedPath = Path(currentItems.firstOrNull() ?: "")

                Timber.d("Input Files: $inputFilesString")
                Timber.d("Parsed Path: ${parsedPath.absolutePathString()}")
                val sanitizedFilename = Utils.sanitizeAndroidFilename(parsedPath.fileName.toString())
                val sanitizedFilenameNoExt = Utils.sanitizeAndroidFilename(parsedPath.nameWithoutExtension)

                val inputParsedData = mutableListOf<InputParsedData>().also {
                    it.add(InputParsedData(name = "LOADING_ACTIVITY", value = processManagerService.getLoadingActivityComponentName()))
                    it.add(InputParsedData(name = "INPUT", value = inputFilesString))
                    it.addSharedTextInput(inputText)
                    it.add(InputParsedData(name = "INPUT_FILES", value = inputFilesString))
                    it.add(InputParsedData(name = "INPUT_FILE", value = parsedPath.absolutePathString()))
                    it.add(InputParsedData(name = "FILENAME", value = sanitizedFilename))
                    it.add(InputParsedData(name = "DIRECTORY", value = "${parsedPath.parent}"))
                    it.add(InputParsedData(name = "FILENAME_NO_EXT", value = sanitizedFilenameNoExt))
                    it.add(InputParsedData(name = "FILE_EXT", value = parsedPath.extension))
                    it.add(InputParsedData(name = "RAND", value = (1000..9999).random().toString()))
                }

                Timber.d("fullExecPath : $fullExecPath")
                Timber.d("Use Python : $usePython")


                Timber.d("Result Command: $resultCommand")

                val processResult = if(Utils.isInteractiveCommand(item.command) && item.multiStage != true){
                    processManagerService.runCommandInTermuxShell(item, fullExecPath, resultCommand, path,
                        inputParsedData,commandExtraInputs,inputFiles.toString(),processId,  JobType.FILES,usePython, isShellScript)
                }else{
                    processManagerService.runCommandForShareWithEnv2(item, fullExecPath, resultCommand, path,
                        inputParsedData,commandExtraInputs,inputFiles.toString(),processId,  JobType.FILES,usePython, isShellScript)
                }


                val result = processResult.toCommandResult(JobType.FILES, inputFiles.toString())

                emit(result)


            } else {

                Timber.d("Single input file")

                currentItems.map { path ->

                    val replacedString = item.command

                    val parsedPath = Path(path)

                    Timber.d("Parsed path: $parsedPath")


                    val execFilePath = processManagerService.getAutoPiePackagePath(item.exec)

                    val dirPath = processManagerService.getCommandWorkingDirectory(item.path)


                    val (_,fullExecPath, resultCommand) = when{
                        File(item.exec).isAbsolute -> {
                            Timber.d("Using package absolute path")
                            ExecAndCommand( ExecType.ABSOLUTE_PATH,item.exec,"\"${item.command}\"")
                        }
                        File(execFilePath).isFile -> {
                            Timber.d("Using autopie package")
                            //For packages installed inside autosec/bin
                            ExecAndCommand( ExecType.AUTOPIE_PACKAGE,execFilePath,"\"${item.command}\"")
                        }
                        else -> {
                            //Base case fallback to terminals installed packages such as busybox packages.
                            Timber.d("Using shell installed program")
                            ExecAndCommand( ExecType.SHELL_INSTALLED,item.exec, item.command)
                        }
                    }

                    val isShellScript = Utils.isShellScript(File(fullExecPath))
                    val usePython = Utils.isZipFile(File(fullExecPath)) || Utils.isPythonScript(item.command)
                    val sanitizedFilename = Utils.sanitizeAndroidFilename(parsedPath.fileName.toString())
                    val sanitizedFilenameNoExt = Utils.sanitizeAndroidFilename(parsedPath.nameWithoutExtension)

                    val inputParsedData = mutableListOf<InputParsedData>().also {
                        it.add(InputParsedData(name = "LOADING_ACTIVITY", value = processManagerService.getLoadingActivityComponentName()))
                        it.add(InputParsedData(name = "INPUT", value = parsedPath.absolutePathString()))
                        it.addSharedTextInput(inputText)
                        it.add(InputParsedData(name = "INPUT_FILES", value = currentItems.joinToString("\n")))
                        it.add(InputParsedData(name = "INPUT_FILE", value = parsedPath.absolutePathString()))
                        it.add(InputParsedData(name = "FILENAME", value = sanitizedFilename))
                        it.add(InputParsedData(name = "DIRECTORY", value = "${parsedPath.parent}"))
                        it.add(InputParsedData(name = "FILENAME_NO_EXT", value = sanitizedFilenameNoExt))
                        it.add(InputParsedData(name = "FILE_EXT", value = parsedPath.extension))
                        it.add(InputParsedData(name = "RAND", value = (1000..9999).random().toString()))
                    }


                    Timber.d("Replaced String $replacedString")

                    val processResult = if(Utils.isInteractiveCommand(item.command) && item.multiStage != true){
                       processManagerService.runCommandInTermuxShell(item, fullExecPath, resultCommand,dirPath,
                            inputParsedData,commandExtraInputs,inputFiles.toString(),processId,  JobType.FILE,usePython, isShellScript)
                    }else{
                        processManagerService.runCommandForShareWithEnv2(item, fullExecPath, resultCommand,dirPath,
                            inputParsedData,commandExtraInputs,inputFiles.toString(),processId,  JobType.FILE,usePython, isShellScript)
                    }



                    val result = processResult.toCommandResult(JobType.FILE, path)

                    emit(result)

                }

            }
        }
    }
}

private fun MutableList<InputParsedData>.addSharedTextInput(inputText: String?) {
    val text = inputText.orEmpty()
    val urls = text.extractHttpUrls()

    add(InputParsedData(name = "INPUT_TEXT", value = text))
    add(InputParsedData(name = "INPUT_URL", value = urls.firstOrNull().orEmpty()))
    add(InputParsedData(name = "INPUT_URLS", value = urls.joinToString(" ")))
}
