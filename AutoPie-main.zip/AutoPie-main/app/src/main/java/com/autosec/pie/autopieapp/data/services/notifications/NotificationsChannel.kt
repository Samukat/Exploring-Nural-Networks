package com.autopi.autopieapp.data.services.notifications

import android.Manifest
import android.app.Activity
import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.autopi.MainActivity
import com.autopi.R
import com.autopi.autopieapp.data.AutoPieConstants
import com.autopi.utils.getIntExtraOrNull
import timber.log.Timber
import java.io.File
import androidx.core.net.toUri
import com.autopi.BuildConfig
import com.autopi.OutputViewerActivity
import com.autopi.OutputPresentationActivity
import com.autopi.autopieapp.data.CommandModel
import com.autopi.autopieapp.data.preferences.AutoPieConfigPathProvider
import com.autopi.autopieapp.data.services.ProcessBroadcastReceiver

class AutoPieNotification(
    val context: Application,
    private val autoPieConfigPathProvider: AutoPieConfigPathProvider,
) {

    companion object{
        const val FOREGROUND_CHANNEL = "foreground_channel"
        const val MAIN_CHANNEL = "autopie_main"
        const val BROADCASTS_CHANNEL = "autopie_command_broadcasts"
        const val MEDIA_CHANNEL = "autopie_media"
    }

    fun createNotificationChannel() {
        try {
            createCommandNotificationChannel()
            createCommandBroadcastNotificationChannel()
            createForegroundChannel()
            createMediaChannel()
        }
        catch (e:Exception){
            Timber.e(e)
        }
    }

    private fun createForegroundChannel(){
        val channel = NotificationChannel(
            FOREGROUND_CHANNEL,
            "Foreground Service",
            NotificationManager.IMPORTANCE_DEFAULT
        )
        val notificationManager: NotificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.createNotificationChannel(channel)
    }

    private fun createCommandNotificationChannel() {
        val channelId = MAIN_CHANNEL
        val channelName = "AutoPie main"
        val channelDescription = "Command Notifications"
        val importance = NotificationManager.IMPORTANCE_DEFAULT
        val channel = NotificationChannel(channelId, channelName, importance).apply {
            description = channelDescription
        }

        val notificationManager: NotificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.createNotificationChannel(channel)
    }

    private fun createCommandBroadcastNotificationChannel() {
        val channelId = BROADCASTS_CHANNEL
        val channelName = "Process broadcasts channel"
        val channelDescription = "Command Broadcasts"
        val importance = NotificationManager.IMPORTANCE_DEFAULT
        val channel = NotificationChannel(channelId, channelName, importance).apply {
            description = channelDescription
        }

        val notificationManager: NotificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.createNotificationChannel(channel)
    }

    private fun createMediaChannel() {
        val channelId = MEDIA_CHANNEL
        val channelName = "Media Events"
        val channelDescription = "Media broadcast"
        val importance = NotificationManager.IMPORTANCE_HIGH
        val channel = NotificationChannel(channelId, channelName, importance).apply {
            description = channelDescription
        }

        val notificationManager: NotificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.createNotificationChannel(channel)
    }


    fun sendNotification(
        contentTitle: String,
        contentText: String,
        command: CommandModel?,
        logFile: String,
        processId: Int,
        silent: Boolean = true,
        autoCancel: Boolean = false,
        reuseProcessNotification: Boolean = false,
        openUrl: String? = null,
        openOutput: Boolean = false,
        rawOutput: String? = null
    ) {
        val channelId = MAIN_CHANNEL
        val notificationId = if (reuseProcessNotification) {
            processId
        } else {
            System.currentTimeMillis().toInt()
        }


        val intent = when {
            openOutput -> outputIntent(processId, command, rawOutput)
            openUrl != null -> openUrl.toSupportedWebUriOrNull()?.let { uri ->
                Intent(Intent.ACTION_VIEW, uri).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            } ?: logIntent(command, logFile)
            else -> logIntent(command, logFile)
        }

        val pendingIntent: PendingIntent = PendingIntent.getActivity(
            context, notificationId, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )


        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_notification)
            .setSilent(silent)
            .setContentTitle(contentTitle)
            .setContentText(contentText)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(autoCancel)

        // Show the notification
        with(NotificationManagerCompat.from(context)) {
            if (ActivityCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {

                //requestNotificationPermission()

                return
            }
            notify(notificationId, builder.build())
        }

        Timber.d("Send notification for $contentTitle, $contentText, $logFile")

    }

    private fun logIntent(command: CommandModel?, logFile: String) =
        Intent(Intent.ACTION_MAIN).apply {
            setClass(context, OutputViewerActivity::class.java)
            putExtra("logFile", logFile)
            putExtra("commandName", command?.name ?: "")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }

    private fun outputIntent(
        processId: Int,
        command: CommandModel?,
        rawOutput: String? = null
    ): Intent {
        val outputFile = if (rawOutput != null) {
            File.createTempFile("notification-output-$processId-", ".json", context.cacheDir)
                .apply { writeText(rawOutput) }
        } else File(context.cacheDir, "$processId.output")
        return OutputPresentationActivity.fileIntent(
            context,
            outputFile,
            command?.name ?: "Command"
        ).apply {
            action = "${context.packageName}.VIEW_OUTPUT.${outputFile.name}"
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
    }

    private fun String.toSupportedWebUriOrNull(): Uri? {
        val uri = toUri()
        val supportedScheme = uri.scheme.equals("https", ignoreCase = true) ||
                uri.scheme.equals("http", ignoreCase = true)
        return uri.takeIf { supportedScheme && !it.host.isNullOrBlank() }
    }

    fun sendBroadcastNotification(
        contentTitle: String,
        contentText: String,
        command: CommandModel?,
        processId: Int,
        logFile: String,
        totalProgress: Int = 100,
        currentProgress: Int? = null
    ) {

        val channelId = BROADCASTS_CHANNEL
        val notificationId = processId


        val intent = Intent(Intent.ACTION_MAIN).apply {
            setClass(context, OutputViewerActivity::class.java)
            putExtra("logFile", logFile)
            putExtra("commandName", command?.name ?: "")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }

        val pendingIntent: PendingIntent = PendingIntent.getActivity(
            context, logFile.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val cancelIntent = Intent(context, ProcessBroadcastReceiver::class.java).apply {
            action = "${context.packageName}.CANCEL_PROCESS"
            putExtra("processId", processId)
        }

        val pendingCancelIntent = PendingIntent.getBroadcast(
            context,
            processId.hashCode(),
            cancelIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )


        var builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_notification)
            .setSilent(true)
            .setContentTitle(contentTitle)
            .setContentText(contentText)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(false)
            .addAction(
                R.drawable.ic_notification,
                "Cancel",
                pendingCancelIntent
            )

        if (currentProgress == null) {
            builder = builder
                .setProgress(0, 0, true)
        } else {
            val maximum = totalProgress.coerceAtLeast(1)
            builder = builder
                .setProgress(maximum, currentProgress.coerceIn(0, maximum), false)
        }

        // Show the notification
        with(NotificationManagerCompat.from(context)) {
            if (ActivityCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {

                //requestNotificationPermission()

                return
            }
            notify(notificationId, builder.build())
        }

        Timber.d("Sent notification for $contentTitle, $contentText, $logFile")

    }

    fun sendMediaReadyNotification(intent: Intent, context: Context) {
        val channelId = MEDIA_CHANNEL

        val notificationId = System.currentTimeMillis().toInt()
        val title = intent.getStringExtra("title")
        val description = intent.getStringExtra("description")
        val mediaUrl = intent.getStringExtra("media_url") ?: "https://google.com"

        Timber.d("Sending notification")

        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, mediaUrl)
        }

        val shareIntent = Intent.createChooser(sendIntent, "Share link with")


        val pendingIntent = PendingIntent.getActivity(
            context, 0, shareIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )


        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_notification)
            .setSilent(false)
            .setContentTitle(title)
            .setContentText(description)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(false)

        // Show the notification
        with(NotificationManagerCompat.from(context)) {
            if (ActivityCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {

                //requestNotificationPermission()

                return
            }
            notify(notificationId, builder.build())
        }
    }

    fun sendBroadcastNotification(intent: Intent, context: Context) {
        val channelId = BROADCASTS_CHANNEL

        val notificationId = intent.getStringExtra("id")?.toInt()
        val title = intent.getStringExtra("title")
        val description = intent.getStringExtra("description")

        val total_progress: Int? = try {
            intent.getIntExtraOrNull("total_progress")
        } catch (e: Exception) {
            null
        }
        val current_progress: Int? = try {
            intent.getIntExtraOrNull("current_progress")
        } catch (e: Exception) {
            null
        }

        fun getOpenUrlIntent(): PendingIntent? {
            if (title?.lowercase()?.contains("rss") == true){
                val urlToOpen = description?.toUri()

                val openUrlIntent =  Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(urlToOpen, "text/plain")  // Adjust MIME type
                }
                val pendingIntent: PendingIntent = PendingIntent.getActivity(
                    context,
                    0,
                    openUrlIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                return pendingIntent
            }
            else return null
        }


        val file = autoPieConfigPathProvider.getLogFile()
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)

        val openFileIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "text/plain")  // Adjust MIME type
            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION  // Grant permission to the app
        }

        val pendingButtonIntent: PendingIntent = PendingIntent.getActivity(
            context,
            0,
            openFileIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        var builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_notification)
            .setSilent(true)
            .setContentTitle(title)
            .setContentText(description)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(getOpenUrlIntent())
            .setAutoCancel(true)
//            .addAction(
//                R.mipmap.ic_launcher,
//                "Open Logs",
//                pendingButtonIntent
//            )
            .addAction(
                R.drawable.ic_notification,
                "Cancel",
                pendingButtonIntent
            )

        if (total_progress == 0) {
            builder = builder
                .setProgress(0, 0, true)
        }

        if (total_progress != null && current_progress != null) {
            builder = builder
                .setProgress(total_progress, current_progress, false)
        }

        // Show the notification
        with(NotificationManagerCompat.from(context)) {
            if (ActivityCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {

                //requestNotificationPermission()

                Timber.d("Notification permission not granted")

                return
            }

            notify(notificationId!!, builder.build())
        }
    }


    fun cancelNotification(intent: Intent, context: Context) {
        val channelId = BROADCASTS_CHANNEL

        val notificationId = intent.getStringExtra("id")?.toInt() ?: return

        with(NotificationManagerCompat.from(context)) {
            cancel(notificationId)
        }
    }

    fun cancelNotification(processId: Int) {
        Timber.d("Canceling notifications with processId $processId")

        val channelId = BROADCASTS_CHANNEL

        val notificationId = processId

        with(NotificationManagerCompat.from(context)) {
            cancel(notificationId)
        }
    }

    fun cancelAllNotifications() {
        Timber.d("Canceling all notifications")
        val channelId = BROADCASTS_CHANNEL

        with(NotificationManagerCompat.from(context)) {
            cancelAll()
        }
    }

    fun requestNotificationPermission(activity: Activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val permission = Manifest.permission.POST_NOTIFICATIONS

            if (ContextCompat.checkSelfPermission(
                    context,
                    permission
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                // Request the permission
                ActivityCompat.requestPermissions(activity, arrayOf(permission), 1)
            }
        }


    }
}
