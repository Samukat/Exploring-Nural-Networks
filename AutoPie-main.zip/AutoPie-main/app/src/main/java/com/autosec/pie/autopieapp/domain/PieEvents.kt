package com.autopi.autopieapp.domain

import com.autopi.autopieapp.data.CommandModel
import com.autopi.autopieapp.data.JobType

sealed class ViewModelEvent {
    data object InstallingPython : ViewModelEvent()
    data object InstalledPythonSuccessfully : ViewModelEvent()
    data object OpenEditCommandSheet : ViewModelEvent()
    data object OpenCloudCommandDetails : ViewModelEvent()
    data object OpenCloudPackageDetails : ViewModelEvent()
    data class OpenCommandDetails(var card: CommandModel) : ViewModelEvent()
    data class OpenCommandHistory(var card: CommandModel) : ViewModelEvent()

    data object RefreshCommandsList : ViewModelEvent()
    data object CommandsConfigChanged : ViewModelEvent()
    data object CloseShareReceiverSheet : ViewModelEvent()
    data class CancelProcess(val processId: Int) : ViewModelEvent()
    data object CancelAllProcesses : ViewModelEvent()
    data class CommandStoppedByUser(val processId: Int) : ViewModelEvent()
    data class CreateShell(val processId: Int) : ViewModelEvent()
    data class StopShell(val processId: Int) : ViewModelEvent()

    data object StopAutoPie : ViewModelEvent()
    data class CommandStarted(val processId: Int,val command: CommandModel, val logFile: String, val input: String, val jobType: JobType) : ViewModelEvent()
    data class CommandCompleted(
        val processId: Int,
        val command: CommandModel,
        val logFile: String,
        val jobType: JobType,
        val partial: Boolean = false,
        val exportedOutput: String? = null
    ) : ViewModelEvent()
    data class CommandFailed(
        val processId: Int,
        val command: CommandModel,
        val logFile: String,
        val jobType: JobType
    ) : ViewModelEvent()
    data object AuthTokenExpired: ViewModelEvent()

}
