package com.autopi.use_case

import com.autopi.autopieapp.data.CommandExtraInput
import com.autopi.autopieapp.data.CommandModel
import com.autopi.autopieapp.data.CommandResult
import com.autopi.autopieapp.data.ExecAndCommand
import com.autopi.autopieapp.data.ExecType
import com.autopi.autopieapp.data.InputParsedData
import com.autopi.autopieapp.data.JobType
import com.autopi.autopieapp.data.services.ProcessManagerService
import com.autopi.utils.Utils
import com.autopi.utils.containsValidHttpUrl
import com.autopi.utils.containsValidUrl
import com.autopi.utils.extractAllUrls
import com.autopi.utils.extractFirstUrl
import com.autopi.utils.toCommandResult
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import timber.log.Timber
import java.io.File

class RunInteractiveCommand(private val processManagerService: ProcessManagerService){
    operator fun invoke(item: CommandModel, text: String, fileUris: List<String>, commandExtraInputs: List<CommandExtraInput> = emptyList(), processId: Int) : Flow<CommandResult> {

        return flow {
            Timber.d("RunCommandForText")

            val execFilePath = processManagerService.getAutoPiePackagePath(item.exec)

            val path = processManagerService.getCommandWorkingDirectory(item.path)


            val (execType,fullExecPath, resultCommand) = when{
                File(item.exec).isAbsolute -> {
                    Timber.d("Using package absolute path")
                    ExecAndCommand( ExecType.ABSOLUTE_PATH,item.exec,"\"${item.command}\"")
                }
                File(execFilePath).isFile -> {
                    Timber.d("Using autopie package")
                    //For packages installed inside autosec/bin
                    ExecAndCommand( ExecType.AUTOPIE_PACKAGE,execFilePath,"\"${item.command}\"")
                }
                else -> {
                    //Base case fallback to terminals installed packages such as busybox packages.
                    Timber.d("Using shell installed program")
                    ExecAndCommand( ExecType.SHELL_INSTALLED,item.exec, item.command)
                }
            }

            val useQuotes = execType != ExecType.SHELL_INSTALLED

            //TODO: Make this more robust
            val inputParsedData = mutableListOf<InputParsedData>().also {
                it.add(InputParsedData(name = "LOADING_ACTIVITY", value = processManagerService.getLoadingActivityComponentName()))
                it.add(InputParsedData(name = "INPUT", value = text))
                it.add(InputParsedData(name = "INPUT_TEXT", value = "$text"))
                it.add(InputParsedData(name = "INPUT_FILE", value = "${if(text.containsValidUrl()) text.extractFirstUrl() else ""}"))
                it.add(InputParsedData(name = "INPUT_FILES", value = "${if(text.containsValidUrl()) text.extractAllUrls() else ""}"))
                it.add(InputParsedData(name = "INPUT_URL", value = "${if(text.containsValidHttpUrl()) text.extractFirstUrl() else ""}"))
                it.add(InputParsedData(name = "INPUT_URLS", value = "${if(text.containsValidHttpUrl()) text.extractAllUrls() else ""}"))
                it.add(InputParsedData(name = "RAND", value = (1000..9999).random().toString()))
            }


            val isShellScript = Utils.isShellScript(File(fullExecPath))
            val usePython = Utils.isZipFile(File(fullExecPath)) || Utils.isPythonScript(item.command)


            Timber.d("Command to run: ${item.exec} $resultCommand")


            val processResult = processManagerService.runCommandInTermuxShell(item, fullExecPath, resultCommand,path ,inputParsedData,commandExtraInputs,text,processId,  JobType.TEXT,usePython, isShellScript)

            val result = processResult.toCommandResult(JobType.TEXT, text)


            emit(result)
        }
    }

}
