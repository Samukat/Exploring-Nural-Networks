package com.autopi.use_case

import com.autopi.autopieapp.data.CommandExtraInput
import com.autopi.autopieapp.data.CommandModel
import com.autopi.autopieapp.data.CommandResult
import com.autopi.autopieapp.data.ExecAndCommand
import com.autopi.autopieapp.data.ExecType
import com.autopi.autopieapp.data.InputParsedData
import com.autopi.autopieapp.data.JobType
import com.autopi.autopieapp.data.services.ProcessManagerService
import com.autopi.utils.Utils
import com.autopi.utils.toCommandResult
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import timber.log.Timber
import java.io.File

class RunCommandForDirectory(private val processManagerService: ProcessManagerService){

    suspend operator fun invoke(
        item: CommandModel,
        inputDir: File,
        commandExtraInputs: List<CommandExtraInput> = emptyList(),
        processId: Int
    ): Flow<CommandResult> {

        return flow {

            Timber.d("runCommandForDirectory")


            val currentItems = inputDir.listFiles()
                ?: throw java.io.IOException("Cannot read input directory: ${inputDir.absolutePath}")


            suspend fun runCommand(path: File): CommandResult {
                val execFilePath = processManagerService.getAutoPiePackagePath(item.exec)

                val cwdPath = processManagerService.getCommandWorkingDirectory(item.path)


                val (_,fullExecPath, resultCommand) = when{
                    File(item.exec).isAbsolute -> {
                        Timber.d("Using package absolute path")
                        ExecAndCommand( ExecType.ABSOLUTE_PATH,item.exec,"\"${item.command}\"")
                    }
                    File(execFilePath).isFile -> {
                        Timber.d("Using autopie package")
                        //For packages installed inside autosec/bin
                        ExecAndCommand( ExecType.AUTOPIE_PACKAGE,execFilePath,"\"${item.command}\"")
                    }
                    else -> {
                        //Base case fallback to terminals installed packages such as busybox packages.
                        Timber.d("Using shell installed program")
                        ExecAndCommand( ExecType.SHELL_INSTALLED,item.exec, item.command)
                    }
                }



                val isShellScript = Utils.isShellScript(File(fullExecPath))
                val usePython = Utils.isZipFile(File(fullExecPath)) || Utils.isPythonScript(item.command)

                val inputFiles = currentItems.joinToString("\n")
                val sanitizedFilename = Utils.sanitizeAndroidFilename(path.name)
                val sanitizedFilenameNoExt = Utils.sanitizeAndroidFilename(path.nameWithoutExtension)

                val inputParsedData = mutableListOf<InputParsedData>().also {
                    it.add(InputParsedData(name = "LOADING_ACTIVITY", value = processManagerService.getLoadingActivityComponentName()))
                    it.add(InputParsedData(name = "INPUT", value = inputDir.absolutePath))
                    it.add(InputParsedData(name = "INPUT_FILES", value = inputFiles))
                    it.add(InputParsedData(name = "INPUT_FILE", value = path.absolutePath))
                    it.add(InputParsedData(name = "FILENAME", value = sanitizedFilename))
                    it.add(InputParsedData(name = "DIRECTORY", value = path.parent ?: ""))
                    it.add(InputParsedData(name = "FILENAME_NO_EXT", value = sanitizedFilenameNoExt))
                    it.add(InputParsedData(name = "FILE_PATH", value = path.parent ?: ""))
                    it.add(InputParsedData(name = "FILE_EXT", value = path.extension))
                    it.add(InputParsedData(name = "RAND", value = (1000..9999).random().toString()))
                }

                val processResult = if(Utils.isInteractiveCommand(item.command) && item.multiStage != true) {
                   processManagerService.runCommandInTermuxShell(item, fullExecPath, resultCommand, cwdPath,
                        inputParsedData,commandExtraInputs,inputDir.absolutePath,processId,  JobType.DIRECTORY,usePython, isShellScript)
                }else{
                    processManagerService.runCommandForShareWithEnv2(item, fullExecPath, resultCommand, cwdPath,
                        inputParsedData,commandExtraInputs,inputDir.absolutePath,processId,  JobType.DIRECTORY,usePython, isShellScript)
                }



                return processResult.toCommandResult(JobType.DIRECTORY, inputDir.path)
            }

            if (item.command.contains("INPUT_FILES")) {
                Timber.d("Multiple input files detected; running directory command once")
                emit(runCommand(currentItems.firstOrNull() ?: inputDir))
            } else {
                currentItems.forEach { path ->
                    emit(runCommand(path))
                }
            }

        }

    }

}
