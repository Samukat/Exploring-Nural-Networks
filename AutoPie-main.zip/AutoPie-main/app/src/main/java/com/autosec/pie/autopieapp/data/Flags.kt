package com.autopi.autopieapp.data

enum class ExtraFlags(val value: String) {
    INTERNAL_CONFIG("--internal-config"),
    PASSWORD("--password"),
    SECRET("--secret"),
    MULTI_FILE_PICKER("--multi-file-picker"),
    FILE_PICKER("--file-picker"),
    FOLDER_PICKER("--folder-picker"),
    MIME_TYPE("--mime-type"),
    INT("--int"),
    SMALL("--small"),
    LARGE("--large"),
    MULTILINE("--multiline"),
    REALTIME("--realtime")
}

enum class ScriptFlags(val value: String) {
    PYTHON("#@PYTHON"),
    INTERACTIVE("#@INTERACTIVE"),
    OPEN_LOGS("#@OPEN_LOGS"),
    SHELL("#@SHELL"),
    BROWSER("//@BROWSER")
}

enum class CommandFlags(val value: String) {
    SHOW_LOADING_SCREEN("--show-loading-screen"),
    SHOW_LOADING_SCREEN_SMALL("--show-loading-screen-small"),
    REALTIME("--realtime")
}



fun List<String>?.hasFlag(flag: ExtraFlags): Boolean =
    orEmpty().any { value -> value.substringBefore("=").trim() == flag.value }

fun List<String>?.hasFlag(flag: CommandFlags): Boolean =
    orEmpty().any { value -> value.substringBefore("=").trim() == flag.value }

fun List<String>?.flagValue(flag: ExtraFlags): String? =
    orEmpty()
        .firstOrNull { value -> value.substringBefore("=").trim() == flag.value }
        ?.substringAfter("=", "")
        ?.trim()
        ?.removeSurrounding("\"")
        ?.removeSurrounding("'")
        ?.takeIf { it.isNotBlank() }

fun List<String>?.withFlag(flag: ExtraFlags, enabled: Boolean): List<String>? {
    val remainingFlags = orEmpty().filterNot { value ->
        value.substringBefore("=").trim() == flag.value
    }
    return (if (enabled) remainingFlags + flag.value else remainingFlags)
        .takeIf(List<String>::isNotEmpty)
}
