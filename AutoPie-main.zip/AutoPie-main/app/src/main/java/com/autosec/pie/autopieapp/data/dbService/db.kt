package com.autopi.autopieapp.data.dbService

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.autopi.autopieapp.data.CommandHistoryEntity
import com.autopi.autopieapp.data.RoomTypeConverters
import com.autopi.autopieapp.data.UserTagEntity
import kotlinx.coroutines.flow.Flow

@Database(entities = [CommandHistoryEntity::class, UserTagEntity::class], version = 6)
@TypeConverters(RoomTypeConverters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun commandHistoryDao(): CommandHistoryDao
    abstract fun userTagsDao(): UserTagsDao
}

@Dao
interface CommandHistoryDao {
    @Query("SELECT * FROM CommandHistoryEntity")
    fun getAll(): List<CommandHistoryEntity>

    @Query("SELECT * FROM CommandHistoryEntity WHERE commandModelId IS :commandName ORDER BY id DESC")
    fun getAllWithName(commandName: String): List<CommandHistoryEntity>

    @Query("""
        SELECT exec
            FROM (
                SELECT *
                FROM CommandHistoryEntity
                WHERE exec IS NOT NULL
                ORDER BY id DESC
            )
        GROUP BY exec
        LIMIT :count;
    """)
    fun getLatestUsedPackages(count: Int): Flow<List<String>>

    @Query("""
        SELECT *
            FROM CommandHistoryEntity
        ORDER BY id DESC
        LIMIT :count;
    """)
    fun getLatestUsedCommands(count: Int): Flow<List<CommandHistoryEntity>>

    @Query("SELECT * FROM CommandHistoryEntity WHERE id LIKE :id LIMIT 1")
    fun findById(id: String): CommandHistoryEntity

    @Insert
    fun insertAll(vararg commandHistory: CommandHistoryEntity)

    @Delete
    fun delete(commandHistory: CommandHistoryEntity)
}

@Dao
interface UserTagsDao {
    @Query("SELECT * FROM UserTagEntity")
    fun getAll(): Flow<List<UserTagEntity>>

    @Query("SELECT * FROM UserTagEntity WHERE tag LIKE :name LIMIT 1")
    fun getTagByName(name: String): UserTagEntity?

    @Insert
    fun insertAll(tags: List<UserTagEntity>)

    @Delete
    fun delete(tag: UserTagEntity)
}

