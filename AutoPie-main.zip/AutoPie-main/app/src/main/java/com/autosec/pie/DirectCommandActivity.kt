package com.autopi

import android.app.Activity
import android.app.ComponentCaller
import com.autopi.autopieapp.domain.ViewModelError

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.SheetValue
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.surfaceColorAtElevation
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.viewModelScope
import com.autopi.autopieapp.data.CommandModel
import com.autopi.autopieapp.data.JobType
import com.autopi.autopieapp.data.ShareInputs
import com.autopi.autopieapp.domain.ViewModelEvent
import com.autopi.autopieapp.presentation.elements.AutoPieLogo
import com.autopi.autopieapp.presentation.elements.SearchBar
import com.autopi.autopieapp.presentation.screens.CommandExtrasBottomSheet
import com.autopi.ui.theme.AutoPieTheme
import com.autopi.utils.Utils.Companion.getPathsFromClipData
import com.autopi.autopieapp.presentation.viewModels.ShareReceiverViewModel
import kotlinx.coroutines.delay
import org.koin.java.KoinJavaComponent.inject
import timber.log.Timber
import com.autopi.utils.getActivity
import org.koin.androidx.compose.koinViewModel
import java.io.File

private data class DirectCommandRequest(val intent: Intent?, val version: Int)

class DirectCommandActivity : ComponentActivity() {

    private var directCommandRequest by mutableStateOf(DirectCommandRequest(null, 0))

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        directCommandRequest = DirectCommandRequest(intent, 0)


        Timber.d(this.intent.toString())
        Timber.d(this.intent.extras.toString())

        setContent {
            val request = directCommandRequest
            val currentIntent = request.intent ?: return@setContent
            val commandId = currentIntent.getStringExtra("commandId")
            val input = currentIntent.getStringExtra("input")
            val isAsync = currentIntent.getBooleanExtra("async", true)
            val processId = currentIntent.getIntExtra("processId", -1).takeIf { it >= 0 }
            val callerPackage = callingPackage ?: referrer?.authority ?: ""
            val callerType = when {
                callerPackage.contains("launcher") -> "DIRECT_ICON"
                callerPackage == "com.autopi" -> "DIRECT_ICON"
                else -> "EXTERNAL_APP"
            }

            Timber.d("Calling package: $callerPackage")

            //val activity = LocalContext.current.getActivity()

            val shareReceiverViewModel: ShareReceiverViewModel = koinViewModel()

            LaunchedEffect(request.version) {
                shareReceiverViewModel.main.eventFlow.collect{
                    when(it){
                        //For asynchronous requests
                        is ViewModelEvent.CommandStarted -> {
                            if (it.jobType == JobType.CRON) return@collect

                            try {
                                val uri = FileProvider.getUriForFile(this@DirectCommandActivity, "${this@DirectCommandActivity.packageName}.fileprovider",
                                    File(it.logFile)
                                )

                                if(callerType == "EXTERNAL_APP" && isAsync && it.command.multiStage != true){
                                    delay(900)
                                    val result = Intent().apply {
                                        putExtra("status", "running")
                                        putExtra("processId", it.processId)
                                        putExtra("logFile", uri.toString())
                                    }
                                    setResult(RESULT_OK, result)
                                    finish()
                                    shareReceiverViewModel.currentExtrasDetails.value = null
                                }
                            }catch (e: Exception){
                                Timber.e(e)
                            }
                        }

                        //For synchronous requests
                        is ViewModelEvent.CommandCompleted -> {
                            if (it.jobType == JobType.CRON) return@collect
                            if (it.partial || shareReceiverViewModel.isOpenRealtimeExtrasProcess(it.processId)) {
                                return@collect
                            }
                            try {
                                val uri = FileProvider.getUriForFile(this@DirectCommandActivity, "${this@DirectCommandActivity.packageName}.fileprovider",
                                    File(it.logFile)
                                )

                                val result = Intent().apply {
                                    putExtra("status", "ok")
                                    putExtra("processId", it.processId)
                                    putExtra("logFile", uri.toString())
                                }
                                setResult(RESULT_OK, result)
                                finish()
                            }catch (e: Exception){
                                Timber.e(e)
                            }
                        }

                        is ViewModelEvent.CommandFailed -> {
                            if (it.jobType == JobType.CRON) return@collect
                            if (shareReceiverViewModel.isOpenRealtimeExtrasProcess(it.processId)) {
                                return@collect
                            }
                            try {
                                val uri = FileProvider.getUriForFile(this@DirectCommandActivity, "${this@DirectCommandActivity.packageName}.fileprovider",
                                    File(it.logFile)
                                )

                                val result = Intent().apply {
                                    putExtra("status", "failed")
                                    putExtra("processId", it.processId)
                                    putExtra("logFile", uri.toString())
                                }
                                setResult(RESULT_OK, result)
                                finish()
                            }catch (e: Exception){
                                Timber.e(e)
                            }
                        }

                        else -> {}
                    }
                }
            }

            LaunchedEffect(commandId, request.version) {
                delay(100L)
                if (commandId != null) {
                    Timber.d("Setting command to $commandId")
                    shareReceiverViewModel.selectCommandFromDirectActivity(
                        commandId,
                        input,
                        callerType,
                        this@DirectCommandActivity,
                        processId
                    )
                }
            }

            DisposableEffect(commandId, request.version) {
                onDispose {
                    Timber.d("Unsetting current command $commandId")
                    shareReceiverViewModel.abandonCurrentInvocation()
                }
            }


            key(request.version) {
                val state = rememberModalBottomSheetState(skipPartiallyExpanded = true, confirmValueChange = {
                    it != SheetValue.Hidden
                })

                val extrasBottomSheetState = rememberModalBottomSheetState(
                    skipPartiallyExpanded = true
                )
                val extrasBottomSheetStateOpen = remember {
                    mutableStateOf(false)
                }

                LaunchedEffect(shareReceiverViewModel.currentExtrasDetails.value) {
                    extrasBottomSheetStateOpen.value = shareReceiverViewModel.currentExtrasDetails.value != null
                }

                AutoPieTheme {
                    CommandExtrasBottomSheet(
                        state = extrasBottomSheetState,
                        open = extrasBottomSheetStateOpen,
                        state,
                        callerName = callerType,
                        isAsync = isAsync
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        directCommandRequest = DirectCommandRequest(intent, directCommandRequest.version + 1)
    }

}
