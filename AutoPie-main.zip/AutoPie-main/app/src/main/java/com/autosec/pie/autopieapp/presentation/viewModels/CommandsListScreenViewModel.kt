package com.autopi.autopieapp.presentation.viewModels

import android.app.Application
import android.os.Environment
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.autopi.core.DispatcherProvider
import com.autopi.autopieapp.data.CommandExtra
import com.autopi.autopieapp.data.CommandModel
import com.autopi.autopieapp.data.CommandType
import com.autopi.autopieapp.domain.ViewModelError
import com.autopi.autopieapp.domain.ViewModelEvent
import com.autopi.autopieapp.data.services.JsonService
import com.autopi.autopieapp.data.services.AutoPieCoreService
import com.autopi.autopieapp.data.matchesSearch
import com.autopi.autopieapp.domain.AppNotification
import com.autopi.autopieapp.domain.model.CloudCommandModel
import com.autopi.autopieapp.domain.model.matchesSearch
import com.autopi.use_case.AutoPieUseCases
import com.autopi.utils.getCommandExec
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.last
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okio.FileNotFoundException
import org.koin.java.KoinJavaComponent
import timber.log.Timber

class CommandsListScreenViewModel(application: Application) : AndroidViewModel(application) {

    val main: MainViewModel by KoinJavaComponent.inject(MainViewModel::class.java)
    private val useCases: AutoPieUseCases by KoinJavaComponent.inject(AutoPieUseCases::class.java)
    val dispatchers: DispatcherProvider by KoinJavaComponent.inject(DispatcherProvider::class.java)

    var fullListOfCommands = MutableStateFlow<List<CommandModel>>(emptyList())
    var fullListOfCommandsShared = fullListOfCommands.asSharedFlow()
    var filteredListOfCommands = MutableStateFlow<List<CommandModel>>(emptyList())
    val repositorySearchResults = MutableStateFlow<List<CloudCommandModel>>(emptyList())
    val isRepositorySearchLoading = mutableStateOf(false)
    private var repositorySearchJob: Job? = null

    val mostUsedPackages: StateFlow<List<String>> =
        getFrequentPackages(fullListOfCommands)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    var selectedICommandTypeIndex by  mutableIntStateOf(0)
    val commandTypeOptions = listOf("All", "Share", "Observers")

    val searchCommandQuery = mutableStateOf("")
    val isLoading = mutableStateOf(false)
    val configUnavailable = mutableStateOf(false)


    init {
        viewModelScope.launch {
            getCommandsList()

            main.eventFlow.collect{
                when(it){
                    is ViewModelEvent.RefreshCommandsList -> {
                        getCommandsList()
                    }
                    else -> {}
                }
            }
        }
    }


    fun getCommandsList(){
        isLoading.value = true

        if(!main.storageManagerPermissionGranted){
            main.showError(ViewModelError.StoragePermissionDenied)
            Timber.e(ViewModelError.StoragePermissionDenied)
            isLoading.value = false
            return
        }

        viewModelScope.launch(dispatchers.io){

            delay(500L)

            try {
                useCases.getCommandsList { skippedCommands ->
                    main.showNotification(AppNotification.CommandsSkipped(skippedCommands))
                }.let { newCommands ->
                    withContext(dispatchers.main){
                        fullListOfCommands.update {
                            newCommands.sortedBy { it.name }
                        }

                        filteredListOfCommands.update {
                            newCommands.sortedBy { it.name }
                        }
                        configUnavailable.value = false

                        if(searchCommandQuery.value.isNotEmpty()){
                            searchInCommands(searchCommandQuery.value)
                        }

                        //mostUsedPackages.update { getFrequentPackages(fullListOfCommands.value) }
                        //setFrequentPackages(fullListOfCommands.value)


                        isLoading.value = false
                    }
                }
            }catch (e: Exception){
                Timber.e(e)

                withContext(dispatchers.main) {
                    isLoading.value = false

                    when (e) {
                        is java.io.FileNotFoundException,
                        is ViewModelError.CommandConfigUnavailable -> {
                            configUnavailable.value = true
                            fullListOfCommands.update { emptyList() }
                            filteredListOfCommands.update { emptyList() }
                        }

                        else -> {
                            configUnavailable.value = false
                        }
                    }
                }

                when(e){
                    is java.io.FileNotFoundException -> {}
                    is ViewModelError.InvalidCommandConfig -> main.showError(ViewModelError.InvalidCommandConfig)
                }
            }
        }
    }



    fun searchInCommands(query: String){
        val trimmedQuery = query.trim()
        val localMatches = fullListOfCommands.value.filter { it.matchesSearch(trimmedQuery) }

        filteredListOfCommands.update {
            localMatches
        }

        repositorySearchJob?.cancel()
        if (trimmedQuery.isBlank()) {
            repositorySearchResults.value = emptyList()
            isRepositorySearchLoading.value = false
            return
        }

        searchRepositoryCommands(trimmedQuery)

    }

    private fun searchRepositoryCommands(query: String) {
        repositorySearchResults.value = emptyList()
        isRepositorySearchLoading.value = true
        repositorySearchJob = viewModelScope.launch(dispatchers.io) {
            delay(250L)
            try {
                AutoPieCoreService.fetchLatestRepositoryJson()
                val installedVersions = fullListOfCommands.value
                    .filter { it.id.isNotBlank() }
                    .associate { it.id to it.version }
                val matches = useCases
                    .getRepoCommandsList(AutoPieCoreService.repositoryJsonFile().absolutePath)
                    .filter { it.matchesSearch(query) }
                    .let { filterUninstalledCloudCommands(it, installedVersions) }
                    .sortedBy { it.name.lowercase() }

                withContext(dispatchers.main) {
                    if (searchCommandQuery.value.trim() == query) {
                        repositorySearchResults.value = matches
                        isRepositorySearchLoading.value = false
                    }
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                Timber.w(error, "Unable to search the commands repository")
                withContext(dispatchers.main) {
                    if (searchCommandQuery.value.trim() == query) {
                        repositorySearchResults.value = emptyList()
                        isRepositorySearchLoading.value = false
                    }
                }
            }
        }
    }

//    fun setFrequentPackages(input: List<CommandModel>){
//        viewModelScope.launch(dispatchers.io){
//            try {
//                val frequencyMap = input.map{it.exec}.groupingBy { it }.eachCount()
//                val packages = frequencyMap.entries.sortedByDescending { it.value }.map { it.key }.take(7)
//
//                val latestUsed = useCases.getLatestUsedPackages(3)
//                val userTags = useCases.getUserTags().last()
//
//                Timber.d("User Tags: $userTags")
//
//                Timber.d("Latest used packages: $latestUsed")
//                mostUsedPackages.update { LinkedHashSet((packages - latestUsed.toSet()) + latestUsed ).toList() }
//            }catch (e: Exception){
//                Timber.e(e)
//            }
//
//        }
//    }

    fun getFrequentPackages(
        inputFlow: StateFlow<List<CommandModel>>
    ): Flow<List<String>> {

        val latestUsedFlow = useCases.getLatestUsedPackages(3).flowOn(dispatchers.io)

        val userTagsFlow = useCases.getUserTags()
            .flowOn(dispatchers.io)

        return combine(
            inputFlow,
            latestUsedFlow,
            userTagsFlow
        ) { input, latestUsed, userTags ->
            val frequencyMap = input.mapNotNull { getCommandExec(it) }
                .groupingBy { it }
                .eachCount()

            val packages = frequencyMap.entries
                .sortedByDescending { it.value }
                .map { it.key }
                .take(7)

            LinkedHashSet(
                (packages - latestUsed.toSet()) + latestUsed + userTags
            ).toList()
        }
    }

    fun deleteUserTag(tag: String){
        viewModelScope.launch(dispatchers.io){
            try {
                useCases.deleteUserTag(tag)
            }catch (e: Exception){
                Timber.d(e)
                when(e){
                    is ViewModelError.TagNotDeletable -> main.showError(ViewModelError.TagNotDeletable)
                }
            }
        }
    }

    fun addUserTag(tag: String){
        viewModelScope.launch(dispatchers.io){
            try {
                useCases.addUserTag(tag)
            }catch (e: Exception){
                Timber.e(e)
            }
        }
    }

    fun filterOnlyShareCommands(){

        filteredListOfCommands.update {
            it.filter { it.type == CommandType.SHARE }
        }

    }

    fun filterOnlyObserverCommands(){

        filteredListOfCommands.update {
            it.filter { it.type == CommandType.FILE_OBSERVER }
        }

    }

    fun noFilter(){

        filteredListOfCommands.update {
            fullListOfCommands.value
        }
    }



}

internal fun filterUninstalledCloudCommands(
    commands: List<CloudCommandModel>,
    installedVersions: Map<String, String>
): List<CloudCommandModel> =
    commands.filterNot { command -> command.id in installedVersions }
