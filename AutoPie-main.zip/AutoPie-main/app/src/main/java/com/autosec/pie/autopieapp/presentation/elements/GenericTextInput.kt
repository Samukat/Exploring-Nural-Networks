package com.autopi.autopieapp.presentation.elements

import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicSecureTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.input.TextFieldState
import androidx.compose.foundation.text.input.TextObfuscationMode
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.RemoveRedEye
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FilePresent
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.autopi.utils.Utils
import timber.log.Timber



@Composable
fun GenericTextFormField(text: MutableState<String>,title: String,subtitle: String? = null, placeholder: String? = null, maxLines: Int? = null, singleLine: Boolean = true,isError: Boolean = false,onValueChange: (String) -> Unit = {}, modifier: Modifier = Modifier, trailingIcon: (@Composable (() -> Unit))? = null, contentAfterSubtitle: (@Composable (() -> Unit))? = null, minLines: Int = if (singleLine) 1 else 2){
    Column {
        if(title.isNotBlank()){
            Text(text = title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(3.dp))
        }

        if(subtitle?.isNotBlank() == true){
            Text(text = subtitle, fontSize = 14.sp, fontWeight = FontWeight.Normal)
        }

        contentAfterSubtitle?.let {
            Spacer(modifier = Modifier.height(8.dp))
            it()
        }

        Spacer(modifier = Modifier.height(10.dp))


        OutlinedTextField(
            shape = RoundedCornerShape(15.dp),
            value = text.value,

            onValueChange = {
                text.value = it
                onValueChange(it)
            },
            trailingIcon = trailingIcon,
            isError = isError,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
            minLines = minLines,
            maxLines = maxLines ?: if (singleLine) 1 else Int.MAX_VALUE,
            colors = OutlinedTextFieldDefaults.colors().copy(unfocusedIndicatorColor = MaterialTheme.colorScheme.primary.copy(.75F)),
            //label = { Text("Search") },
            placeholder = { placeholder?.let{Text(it)} },
            singleLine = singleLine,
            modifier = Modifier
                .fillMaxWidth()
                .then(modifier)


        )
    }
}

@Composable
fun GenericTextAndSelectorFormField(text: MutableState<String>,title: String, modifier: Modifier = Modifier,subtitle: String? = null, placeholder: String? = null, maxLines: Int? = null, singleLine: Boolean = true,isError: Boolean = false,useRelativePaths: Boolean = false,onValueChange: (String) -> Unit = {}){


    Column {
        if(title.isNotBlank()){
            Text(text = title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(3.dp))
        }

        if(subtitle?.isNotBlank() == true){
            Text(text = subtitle, fontSize = 14.sp, fontWeight = FontWeight.Normal)
        }

        Spacer(modifier = Modifier.height(10.dp))


        OutlinedTextField(
            shape = RoundedCornerShape(15.dp),
            value = text.value,

            onValueChange = {
                text.value = it
                onValueChange(it)
            },
            trailingIcon = {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    MultiFilePicker(useRelativePaths){
                        text.value = it.joinToString(",")
                    }
                }
            },
            isError = isError,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
            minLines = 2,
            maxLines = Int.MAX_VALUE,
            colors = OutlinedTextFieldDefaults.colors().copy(unfocusedIndicatorColor = MaterialTheme.colorScheme.primary.copy(.75F)),
            //label = { Text("Search") },
            placeholder = { placeholder?.let{Text(it)} },
            singleLine = singleLine,
            modifier = Modifier
                .fillMaxWidth()
                .then(modifier)


        )
    }
}

@RequiresApi(Build.VERSION_CODES.Q)
@Composable
fun MultiFilePicker(
    useRelativePaths: Boolean = false,
    mimeType: String = "*/*",
    onFilesPicked: (List<String>) -> Unit
) {
    val context = LocalContext.current
    val requestedMimeType = mimeType.ifBlank { "*/*" }
    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        Timber.tag("UriResolver").d("Multi-file picker returned %d URI(s): %s", uris.size, uris)
        val paths = uris.mapNotNull { uri ->
            Timber.tag("UriResolver").d(
                "Processing selected URI: uri=%s mimeType=%s useRelativePaths=%s",
                uri,
                context.contentResolver.getType(uri),
                useRelativePaths
            )
            val path = if(useRelativePaths) Utils.getRelativePathFromUri(context ,uri) else Utils.getAbsolutePathFromUri2(context ,uri)
            Timber.tag("UriResolver").d("Multi-file picker resolved URI: uri=%s path=%s", uri, path)
            path
        }
        Timber.tag("UriResolver").d("Multi-file picker final paths: %s", paths)
        onFilesPicked(paths)
    }

    // Call this when you want to launch the picker, for example on button click
    remember { launcher }

    IconButton(onClick = {
        Timber.tag("UriResolver").d("Launching multi-file picker with MIME type: %s", requestedMimeType)
        launcher.launch(arrayOf(requestedMimeType))
    }) {
        Icon(
            imageVector = Icons.Rounded.FilePresent,
            contentDescription = "File Picker",
            tint = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.size(25.dp)
        )
    }
}

@RequiresApi(Build.VERSION_CODES.Q)
@Composable
fun SingleFilePicker(
    useRelativePaths: Boolean = false,
    mimeType: String = "*/*",
    onFilesPicked: (String) -> Unit,
) {
    val context = LocalContext.current
    val requestedMimeType = mimeType.ifBlank { "*/*" }
    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        Timber.tag("UriResolver").d(
            "Single-file picker returned URI: uri=%s mimeType=%s useRelativePaths=%s",
            uri,
            uri?.let(context.contentResolver::getType),
            useRelativePaths
        )
        uri?.let{
            val path =  if(useRelativePaths) Utils.getRelativePathFromUri(context ,uri) else Utils.getAbsolutePathFromUri2(context ,uri)

            Timber.tag("UriResolver").d("Single-file picker resolved URI: uri=%s path=%s", uri, path)

            path?.let {
                onFilesPicked(it)
            } ?: Timber.tag("UriResolver").w("Single-file picker dropped unresolved URI: %s", uri)
        } ?: run {
            Timber.tag("UriResolver").w("Single-file picker was dismissed without a URI")
        }
    }

    remember { launcher }

    IconButton(onClick = {
        Timber.tag("UriResolver").d("Launching single-file picker with MIME type: %s", requestedMimeType)
        launcher.launch(arrayOf(requestedMimeType))
    }) {
        Icon(
            imageVector = Icons.Rounded.FilePresent,
            contentDescription = "File Picker",
            tint = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.size(25.dp)
        )
    }
}

@RequiresApi(Build.VERSION_CODES.Q)
@Composable
fun FolderPicker(
    useRelativePaths: Boolean = false,
    onFolderPicked: (String) -> Unit,
) {
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        Timber.tag("UriResolver").d(
            "Folder picker returned URI: uri=%s useRelativePaths=%s",
            uri,
            useRelativePaths
        )
        uri?.let {
            val path = if (useRelativePaths) {
                Utils.getRelativePathFromUri(context, uri)
            } else {
                Utils.getAbsolutePathFromUri2(context, uri)
            }

            Timber.tag("UriResolver").d("Folder picker resolved URI: uri=%s path=%s", uri, path)
            path?.let(onFolderPicked)
                ?: Timber.tag("UriResolver").w("Folder picker dropped unresolved URI: %s", uri)
        } ?: Timber.tag("UriResolver").w("Folder picker was dismissed without a URI")
    }

    IconButton(onClick = {
        Timber.tag("UriResolver").d("Launching folder picker")
        launcher.launch(null)
    }) {
        Icon(
            imageVector = Icons.Rounded.Folder,
            contentDescription = "Folder Picker",
            tint = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.size(25.dp)
        )
    }
}

@Composable
fun GenericTextFormField(text: MutableState<String>,title: String,subtitle: AnnotatedString, modifier: Modifier = Modifier, placeholder: String? = null, maxLines: Int? = null, singleLine: Boolean = true,isError: Boolean = false,onValueChange: (String) -> Unit = {}){
    Column {
        if(title.isNotBlank()){
            Text(text = title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(3.dp))
        }

        if(subtitle?.isNotBlank() == true){
            Text(text = subtitle, fontSize = 14.sp, fontWeight = FontWeight.Normal)
        }

        Spacer(modifier = Modifier.height(10.dp))


        OutlinedTextField(
            shape = RoundedCornerShape(15.dp),
            value = text.value,

            onValueChange = {
                text.value = it
                onValueChange(it)
            },
            isError = isError,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
            minLines = 2,
            maxLines = Int.MAX_VALUE,
            colors = OutlinedTextFieldDefaults.colors().copy(unfocusedIndicatorColor = MaterialTheme.colorScheme.primary.copy(.75F)),
            //label = { Text("Search") },
            placeholder = { placeholder?.let{Text(it)} },
            singleLine = singleLine,
            modifier = Modifier
                .fillMaxWidth()
                .then(modifier)


        )
    }
}

@Composable
fun GenericFormSwitch(text: String, switchState: MutableState<Boolean>,modifier: Modifier = Modifier, onChange: (Boolean) -> Unit){
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
    ) {
        Text(text, fontSize = 16.4.sp, fontWeight = FontWeight.SemiBold)
        Switch(checked = switchState.value, onCheckedChange = {
                onChange(it)
        })
    }
}




@Composable
fun PasswordFormField(text: MutableState<String>,title: String, modifier: Modifier = Modifier,subtitle: String? = null, placeholder: String? = null, maxLines: Int? = null, singleLine: Boolean = true,isError: Boolean = false,onValueChange: (String) -> Unit = {}, trailingIcon: (@Composable (() -> Unit))? = null, mask: Char = '⬤', minLines: Int = if (singleLine) 1 else 2){
    Column {
        if(title.isNotBlank()){
            Text(text = title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(3.dp))
        }

        if(subtitle?.isNotBlank() == true){
            Text(text = subtitle, fontSize = 14.sp, fontWeight = FontWeight.Normal)
        }

        Spacer(modifier = Modifier.height(10.dp))


        OutlinedTextField(
            shape = RoundedCornerShape(15.dp),
            value = text.value,
            visualTransformation = PasswordVisualTransformation(mask = mask),
            onValueChange = {
                text.value = it
                onValueChange(it)
            },
            trailingIcon = trailingIcon,
            isError = isError,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            minLines = minLines,
            maxLines = maxLines ?: if (singleLine) 1 else Int.MAX_VALUE,
            colors = OutlinedTextFieldDefaults.colors().copy(unfocusedIndicatorColor = MaterialTheme.colorScheme.primary.copy(.75F)),
            //label = { Text("Search") },
            placeholder = { placeholder?.let{Text(it)} },
            singleLine = singleLine,
            modifier = Modifier
                .fillMaxWidth()
                .then(modifier)


        )
    }
}
