package com.autopi.autopieapp.presentation.elements

import android.os.Build
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.UnfoldMore
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.surfaceColorAtElevation
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.autopi.autopieapp.data.AutoPieStrings
import com.autopi.autopieapp.data.CommandExtra
import com.autopi.autopieapp.data.ExtraFlags
import com.autopi.autopieapp.data.SECRET_VALUE_PLACEHOLDER
import com.autopi.autopieapp.data.flagValue
import com.autopi.autopieapp.data.hasFlag
import com.autopi.autopieapp.data.isMultilineText
import com.autopi.autopieapp.data.isSecretExtra
import com.autopi.autopieapp.data.secretKey
import com.autopi.autopieapp.data.withFlag
import com.autopi.autopieapp.data.services.SecretsService
import org.koin.java.KoinJavaComponent


@Composable
fun CommandExtraElement(
    extrasElements: MutableState<List<CommandExtra>>,
    onAddCommandExtra: (CommandExtra) -> Unit,
    onRemoveCommandExtra: (String) -> Unit,
    commandId: String? = null,
) {

    val rowState = rememberLazyListState()

    val derivedCommandName = remember {
        derivedStateOf { extrasElements.value.firstOrNull()?.name }
    }

    val modifiedExtraDescription = remember {
        derivedStateOf {
            if (derivedCommandName.value?.isNotBlank() == true) AutoPieStrings.EXTRAS_DESCRIPTION.replace(
                AutoPieStrings.EXTRAS_DESCRIPTION_TO_REPLACE,
                derivedCommandName.value!!
            ) else AutoPieStrings.EXTRAS_DESCRIPTION
        }
    }

    val scrollState = rememberScrollState()


    Column {
        Text(text = "EXTRAS", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(3.dp))

        Text(
            text = modifiedExtraDescription.value,
            fontSize = 14.sp,
            fontWeight = FontWeight.Normal
        )
        Spacer(modifier = Modifier.height(10.dp))

//        LazyRow(state = rowState, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
//            items(items = extrasElements.value, key = { it.id }) {
//                CommandExtraInputElement(it, extrasElements, onAddCommandExtra, onRemoveCommandExtra)
//            }
//        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.horizontalScroll(scrollState)
        ) {
            for (item in extrasElements.value.reversed()) {
                key(item.id){
                    CommandExtraInputElement(item, extrasElements, onAddCommandExtra, onRemoveCommandExtra, commandId)
                }
            }
        }
    }

}


@Composable
fun CommandExtraInputElement(
    command: CommandExtra,
    extrasElements: MutableState<List<CommandExtra>>,
    onAddCommandExtra: (CommandExtra) -> Unit,
    onRemoveCommandExtra: (String) -> Unit,
    commandId: String? = null
) {
    val secretsService: SecretsService by KoinJavaComponent.inject(SecretsService::class.java)


    val name = rememberSaveable {
        mutableStateOf(command.name)
    }.also {
        it.value = it.value.uppercase()
    }

    val displayedDefault = remember(command.id, command.name, command.default, commandId) {
        if (
            commandId != null &&
            command.isSecretExtra() &&
            secretsService.get(command.secretKey(commandId)) != null
        ) {
            SECRET_VALUE_PLACEHOLDER
        } else {
            command.default
        }
    }

    val default = rememberSaveable(command.id, displayedDefault) {
        mutableStateOf(displayedDefault)
    }

    val selectableOptions = rememberSaveable {
        mutableStateOf(
            command.selectableOptions.orEmpty().entries.joinToString(",") { (label, value) ->
                if (label == value) label else "$label=$value"
            }
        )
    }

    val description = rememberSaveable {
        mutableStateOf(command.description)
    }

    val isRequired = rememberSaveable {
        mutableStateOf(command.required)
    }

    var expanded = remember { mutableStateOf(false) }
    var selectedCommandType =
        rememberSaveable {
            mutableStateOf(
                if (command.isMultilineText()) "TEXT"
                else command.type.split(",").firstOrNull() ?: ""
            )
        }
    val options = listOf(
        "STRING",
        "TEXT",
        "SELECTABLE",
        "SELECTABLE_FLAT",
        "BUTTON",
        "MULTI_SELECTABLE",
        "MULTI_SELECTABLE_FLAT",
        "FLAG",
        "BOOLEAN",
        "SLIDER"
    )

    //Boolean extra options
    var booleanExpanded = remember { mutableStateOf(false) }
    var selectedOptionForBoolean =
        rememberSaveable { mutableStateOf(command.defaultBoolean.toString()) }
    val booleanOptions = listOf("TRUE", "FALSE")

    val sliderOptions = rememberSaveable {
        mutableStateOf(command.default)
    }

    val pickerMimeType = command.flags.flagValue(ExtraFlags.MIME_TYPE) ?: "*/*"


    LaunchedEffect(
        listOf(
            name.value,
            default.value,
            selectableOptions.value,
            description.value,
            selectedCommandType.value,
            selectedOptionForBoolean.value,
            isRequired.value
        )
    ) {

        val parsedSelectableOptions = selectableOptions.value
            .split(",")
            .map(String::trim)
            .filter(String::isNotEmpty)
            .associateTo(linkedMapOf()) { option ->
                val label = option.substringBefore("=").trim()
                val value = option.substringAfter("=", option).trim()
                label to value
            }

        val commandExtra = CommandExtra(
            id = command.id,
            name = name.value,
            type = if (selectedCommandType.value == "TEXT") "STRING" else selectedCommandType.value,
            default = when{
                selectedCommandType.value == "SELECTABLE" ||
                    selectedCommandType.value == "SELECTABLE_FLAT" ||
                    selectedCommandType.value == "BUTTON" ||
                    selectedCommandType.value == "MULTI_SELECTABLE" ||
                    selectedCommandType.value == "MULTI_SELECTABLE_FLAT" ->
                    parsedSelectableOptions.values.firstOrNull() ?: ""
                else -> default.value
            },
            description = description.value,
            defaultBoolean = selectedOptionForBoolean.value.toBoolean(),
            selectableOptions = parsedSelectableOptions,
            required = isRequired.value,
            flags = command.flags.withFlag(
                ExtraFlags.MULTILINE,
                selectedCommandType.value == "TEXT"
            ),
            visibleWhen = command.visibleWhen
        )

        onAddCommandExtra(commandExtra)

    }


    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(15.dp))
            .background(MaterialTheme.colorScheme.surfaceColorAtElevation(30.dp))
            .width(300.dp)
            //.height(90.dp)
            .padding(15.dp),
        verticalArrangement = Arrangement.spacedBy(15.dp)
    ) {

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(Modifier.fillMaxWidth(0.7F)) {
                OptionSelector(options, selectedCommandType, expanded)
            }

            Box(
                Modifier
                    .padding(2.dp)
                    .clip(RoundedCornerShape(15.dp))
                    .height(55.dp)
                    .aspectRatio(1F, true)
                    .background(MaterialTheme.colorScheme.surfaceColorAtElevation(90.dp))
                    .clickable {

                        onRemoveCommandExtra(command.id)

                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = "Settings",
                    tint = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.size(25.dp)
                )
            }
        }


        when (selectedCommandType.value) {
            "STRING", "TEXT" -> {
                GenericTextFormField(
                    text = name,
                    "",
                    placeholder = "NAME",
                    isError = name.value.isBlank(),


                    )
                GenericTextFormField(
                    text = default,
                    "",
                    placeholder = "DEFAULT",
                    singleLine = selectedCommandType.value != "TEXT",
                    minLines = if (selectedCommandType.value == "TEXT") 4 else 1,
                    isError = default.value.isBlank(),
                    trailingIcon = if(
                        command.flags.hasFlag(ExtraFlags.FOLDER_PICKER) ||
                        name.value.endsWith("FOLDER")
                    ) {
                        {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                FolderPicker(useRelativePaths = true) {
                                    default.value = it
                                }
                            }
                        }
                    } else if(
                        command.flags.hasFlag(ExtraFlags.FILE_PICKER) ||
                        name.value.endsWith("FILE")
                    ){
                        {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                SingleFilePicker(
                                    useRelativePaths = true,
                                    mimeType = pickerMimeType
                                ) {
                                    default.value = it
                                }
                            }
                        }
                    }else if(
                        command.flags.hasFlag(ExtraFlags.MULTI_FILE_PICKER) ||
                        name.value.endsWith("FILES")
                    ) {
                        {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                MultiFilePicker(
                                    useRelativePaths = true,
                                    mimeType = pickerMimeType
                                ) {
                                    default.value = it.joinToString(",")
                                }
                            }
                        }
                    }else {
                        null
                    }
                )
                GenericTextFormField(
                    text = description,
                    "",
                    placeholder = "DESCRIPTION",
                    singleLine = false,
                )
                if(default.value.isEmpty()){
                    GenericFormSwitch(
                        text = "Required",
                        switchState = isRequired,
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                        onChange = { isRequired.value = it }
                    )
                }
            }

            "BOOLEAN" -> {
                GenericTextFormField(
                    text = name,
                    "",
                    placeholder = "NAME",
                    isError = name.value.isBlank()
                )
                OptionSelector(
                    options = booleanOptions,
                    selectedOption = selectedOptionForBoolean,
                    expanded = booleanExpanded
                )
                GenericTextFormField(
                    text = description,
                    "",
                    placeholder = "DESCRIPTION",
                    singleLine = false,
                )
            }

            "SELECTABLE", "SELECTABLE_FLAT", "BUTTON", "MULTI_SELECTABLE", "MULTI_SELECTABLE_FLAT" -> {
                GenericTextFormField(
                    text = name,
                    "",
                    placeholder = "NAME",
                )
                GenericTextFormField(
                    text = selectableOptions,
                    "",
                    placeholder = "OPTIONS",
                    subtitle = if (
                        selectedCommandType.value == "MULTI_SELECTABLE" ||
                        selectedCommandType.value == "MULTI_SELECTABLE_FLAT"
                    ) {
                        "Separate options with commas. Users can select multiple values; selected raw values are joined with a new line."
                    } else {
                        "Separate options with commas. Use Label=raw value for a user-friendly label. The first value is the default."
                    },
                    isError = selectableOptions.value.isBlank()
                )
                GenericTextFormField(
                    text = description,
                    "",
                    placeholder = "DESCRIPTION",
                    singleLine = false,
                )
            }
            "SLIDER" -> {
                GenericTextFormField(
                    text = name,
                    "",
                    placeholder = "NAME",
                )
                GenericTextFormField(
                    text = default,
                    "",
                    placeholder = "OPTIONS",
                    subtitle = "Options for this field. Separate options with commas (FROM,DEFAULT,TO)",
                    isError = default.value.isBlank()
                )
                GenericTextFormField(
                    text = description,
                    "",
                    placeholder = "DESCRIPTION",
                    singleLine = false,
                )
            }
            "FLAG" -> {
                GenericTextFormField(
                    text = name,
                    "",
                    placeholder = "NAME",
                )
                GenericTextFormField(
                    text = default,
                    "",
                    placeholder = "FLAG",
                    subtitle = "Flag to set. Eg --flag. Checkbox will be shown to select/deselect.",
                    isError = default.value.isBlank()
                )
                Text(
                    text = "ENABLED BY DEFAULT",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
                OptionSelectorBoolean(
                    options = booleanOptions,
                    selectedOption = selectedOptionForBoolean,
                    expanded = booleanExpanded
                )
                GenericTextFormField(
                    text = description,
                    "",
                    placeholder = "DESCRIPTION",
                    singleLine = false,
                )
            }

        }

    }
}

@Composable
fun OptionSelectorBoolean(
    options: List<String>,
    selectedOption: MutableState<String>,
    expanded: MutableState<Boolean>
) {


    Column(
        modifier = Modifier
            .border(
                2.dp,
                MaterialTheme.colorScheme.primary,
                RoundedCornerShape(15.dp)
            )
            .height(57.dp)
            .clip(RoundedCornerShape(15.dp))
            .background(Color.Black.copy(alpha = 0.15F))
            .clickable { expanded.value = true }
    ) {
        Row(horizontalArrangement = Arrangement.SpaceBetween){
            Text(
                text = selectedOption.value.uppercase(),
                modifier = Modifier
                    //.clip(RoundedCornerShape(15.dp))
                    .fillMaxWidth(0.7F)
                    .padding(16.dp)
            )
            Box(Modifier
                .fillMaxHeight()
                .aspectRatio(1F), contentAlignment = Alignment.Center){
                Icon(
                    tint = MaterialTheme.colorScheme.primary,
                    imageVector = Icons.Default.UnfoldMore,
                    contentDescription = "Show options",
                    modifier = Modifier.size(30.dp)
                )
            }
        }

        DropdownMenu(
            expanded = expanded.value,
            onDismissRequest = { expanded.value = false },
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    onClick = {
                        selectedOption.value = option.toBoolean().toString()
                        expanded.value = false
                    },
                    text = { Text(option) }
                )
            }
        }
    }
}

@Composable
fun OptionSelector(
    options: Map<String, String>,
    selectedOption: MutableState<String>,
    expanded: MutableState<Boolean>,
    enabled: Boolean = true
) {
    val selectedLabel = options.entries
        .firstOrNull { it.value == selectedOption.value }
        ?.key
        ?: selectedOption.value

    Column(
        modifier = Modifier
            .border(
                2.dp,
                if (enabled) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.25F),
                RoundedCornerShape(15.dp)
            )
            .height(57.dp)
            .clip(RoundedCornerShape(15.dp))
            .background(
                if (enabled) Color.Black.copy(alpha = 0.15F)
                else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08F)
            )
            .clickable(enabled = enabled) { expanded.value = true }
    ) {
        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth(0.9F)) {
            Text(
                text = selectedLabel,
                color = if (enabled) MaterialTheme.colorScheme.onSurface
                else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38F),
                softWrap = false,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .fillMaxWidth(0.85F)
                    .padding(top = 16.dp, bottom = 16.dp, start = 16.dp)
            )
            Box(
                Modifier
                    .fillMaxHeight()
                    .aspectRatio(1F),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    tint = if (enabled) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.25F),
                    imageVector = Icons.Default.UnfoldMore,
                    contentDescription = "Show options",
                    modifier = Modifier.size(30.dp)
                )
            }
        }

        DropdownMenu(
            expanded = enabled && expanded.value,
            onDismissRequest = { expanded.value = false },
        ) {
            options.forEach { (label, value) ->
                DropdownMenuItem(
                    onClick = {
                        selectedOption.value = value
                        expanded.value = false
                    },
                    text = { Text(label) }
                )
            }
        }
    }
}

@Composable
fun ButtonOptionSelector(
    options: Map<String, String>,
    selectedOption: MutableState<String>,
    enabled: Boolean = true,
    onOptionClick: (String) -> Unit = {},
) {
    if (!enabled) {
        Text(
            text = "Error fetching",
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38F)
        )
        return
    }

    if (options.isEmpty()) {
        Text(
            text = "No options available",
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        return
    }

    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
        val columnCount = when {
            maxWidth >= 600.dp -> 4
            maxWidth >= 420.dp -> 3
            else -> 2
        }.coerceAtMost(options.size)
        val optionRows = options.entries.chunked(columnCount)

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            optionRows.forEach { rowOptions ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    rowOptions.forEach { (label, value) ->
                        val selected = selectedOption.value == value
                        Button(
                            onClick = {
                                selectedOption.value = value
                                onOptionClick(value)
                            },
                            modifier = Modifier
                                .weight(1F)
                                .heightIn(min = 52.dp),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(
                                width = 1.dp,
                                color = if (selected) {
                                    MaterialTheme.colorScheme.primary
                                } else {
                                    MaterialTheme.colorScheme.outlineVariant
                                }
                            ),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selected) {
                                    MaterialTheme.colorScheme.primaryContainer
                                } else {
                                    MaterialTheme.colorScheme.surfaceColorAtElevation(2.dp)
                                },
                                contentColor = if (selected) {
                                    MaterialTheme.colorScheme.onPrimaryContainer
                                } else {
                                    MaterialTheme.colorScheme.onSurface
                                }
                            ),
                            elevation = ButtonDefaults.buttonElevation(
                                defaultElevation = if (selected) 0.dp else 1.dp,
                                pressedElevation = 0.dp
                            ),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(
                                horizontal = 12.dp,
                                vertical = 10.dp
                            )
                        ) {
                            Text(
                                text = label,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    repeat(columnCount - rowOptions.size) {
                        Spacer(modifier = Modifier.weight(1F))
                    }
                }
            }
        }
    }
}

@Composable
fun MultiOptionSelector(
    options: Map<String, String>,
    selectedOptions: MutableState<List<String>>,
    expanded: MutableState<Boolean>,
    enabled: Boolean = true,
) {
    val selectedLabels = options
        .filterValues { it in selectedOptions.value }
        .keys
        .joinToString(", ")
        .ifEmpty { if (enabled) "Select options" else "Error fetching" }

    Column(
        modifier = Modifier
            .border(
                2.dp,
                if (enabled) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.25F),
                RoundedCornerShape(15.dp)
            )
            .height(57.dp)
            .clip(RoundedCornerShape(15.dp))
            .background(
                if (enabled) Color.Black.copy(alpha = 0.15F)
                else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08F)
            )
            .clickable(enabled = enabled) { expanded.value = true }
    ) {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth(0.9F)
        ) {
            Text(
                text = selectedLabels,
                color = if (enabled) MaterialTheme.colorScheme.onSurface
                else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38F),
                softWrap = false,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .fillMaxWidth(0.85F)
                    .padding(top = 16.dp, bottom = 16.dp, start = 16.dp)
            )
            Box(
                Modifier
                    .fillMaxHeight()
                    .aspectRatio(1F),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    tint = if (enabled) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.25F),
                    imageVector = Icons.Default.UnfoldMore,
                    contentDescription = "Show options",
                    modifier = Modifier.size(30.dp)
                )
            }
        }

        DropdownMenu(
            expanded = enabled && expanded.value,
            onDismissRequest = { expanded.value = false },
        ) {
            options.forEach { (label, value) ->
                val selected = value in selectedOptions.value
                DropdownMenuItem(
                    onClick = {
                        selectedOptions.value = if (selected) {
                            selectedOptions.value - value
                        } else {
                            selectedOptions.value + value
                        }
                    },
                    leadingIcon = {
                        Checkbox(
                            checked = selected,
                            onCheckedChange = null
                        )
                    },
                    text = { Text(label) }
                )
            }
        }
    }
}

@Composable
fun FlatOptionSelector(
    options: Map<String, String>,
    selectedOption: MutableState<String>,
    enabled: Boolean = true,
) {
    if (!enabled) {
        Text(
            text = "Error fetching",
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38F)
        )
        return
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(15.dp))
            .background(Color.Black.copy(alpha = 0.25F))
    ) {
        options.entries.forEachIndexed { index, (label, value) ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { selectedOption.value = value }
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier.size(36.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (selectedOption.value == value) {
                        Icon(
                            imageVector = Icons.Rounded.Check,
                            contentDescription = "Selected",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
                Text(
                    text = label,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
            if (index < options.size - 1) {
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            }
        }
    }
}

@Composable
fun FlatMultiOptionSelector(
    options: Map<String, String>,
    selectedOptions: MutableState<List<String>>,
    enabled: Boolean = true,
) {
    if (!enabled) {
        Text(
            text = "Error fetching",
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38F)
        )
        return
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(15.dp))
            .background(Color.Black.copy(alpha = 0.25F))
    ) {
        options.entries.forEachIndexed { index, (label, value) ->
            val selected = value in selectedOptions.value
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        selectedOptions.value = if (selected) {
                            selectedOptions.value - value
                        } else {
                            selectedOptions.value + value
                        }
                    }
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier.size(36.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (selected) {
                        Icon(
                            imageVector = Icons.Rounded.Check,
                            contentDescription = "Selected",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
                Text(
                    text = label,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
            if (index < options.size - 1) {
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            }
        }
    }
}

@Composable
fun OptionSelector(
    options: List<String>,
    selectedOption: MutableState<String>,
    expanded: MutableState<Boolean>
) {


    Column(
        modifier = Modifier
            .border(
                2.dp,
                MaterialTheme.colorScheme.primary,
                RoundedCornerShape(15.dp)
            )
            .height(57.dp)
            .clip(RoundedCornerShape(15.dp))
            .background(Color.Black.copy(alpha = 0.15F))
            .clickable { expanded.value = true }
    ) {
        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth(0.9F)){
            Text(
                text = selectedOption.value,
                softWrap = false,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .fillMaxWidth(0.85F)
                    .padding(top = 16.dp, bottom = 16.dp, start = 16.dp)
            )
            Box(Modifier
                .fillMaxHeight()
                .aspectRatio(1F), contentAlignment = Alignment.Center){
                Icon(
                    tint = MaterialTheme.colorScheme.primary,
                    imageVector = Icons.Default.UnfoldMore,
                    contentDescription = "Show options",
                    modifier = Modifier.size(30.dp)
                )
            }
        }

        DropdownMenu(
            expanded = expanded.value,
            onDismissRequest = { expanded.value = false },
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    onClick = {
                        selectedOption.value = option
                        expanded.value = false
                    },
                    text = { Text(option) }
                )
            }
        }
    }
}
