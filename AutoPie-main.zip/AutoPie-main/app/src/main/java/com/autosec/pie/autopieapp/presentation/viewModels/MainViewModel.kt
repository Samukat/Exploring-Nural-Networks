package com.autopi.autopieapp.presentation.viewModels

import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.util.AtomicFile
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.autopi.BuildConfig
import com.autopi.autopieapp.data.AutoPieConstants
import com.autopi.autopieapp.data.CommandModel
import com.autopi.autopieapp.data.CommandType
import com.autopi.autopieapp.data.CommandsRepositoryChannel
import com.autopi.autopieapp.data.HomeCommandPreview
import com.autopi.autopieapp.data.JobType
import com.autopi.core.DispatcherProvider
import com.autopi.autopieapp.data.preferences.AppPreferences
import com.autopi.autopieapp.data.preferences.AutoPieConfigLocation
import com.autopi.autopieapp.data.preferences.AutoPieConfigPathProvider
import com.autopi.autopieapp.domain.AppNotification
import com.autopi.autopieapp.domain.Notification
import com.autopi.autopieapp.domain.ViewModelError
import com.autopi.autopieapp.domain.ViewModelEvent
import com.autopi.autopieapp.data.services.AutoPieCoreService
import com.autopi.autopieapp.data.services.ConfigBackupService
import com.autopi.autopieapp.data.services.FileObserverScheduler
import com.autopi.autopieapp.data.services.GithubApiService
import com.autopi.autopieapp.data.services.ProcessManagerService
import com.autopi.autopieapp.data.services.ReleaseInfo
import com.autopi.autopieapp.domain.model.CloudCommandModel
import com.autopi.use_case.AutoPieUseCases
import com.autopi.use_case.DependencyRestorePlan
import com.autopi.use_case.RestoreCommandDependencies
import com.google.gson.JsonParser
import com.google.gson.GsonBuilder
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.koin.java.KoinJavaComponent
import org.koin.java.KoinJavaComponent.inject
import timber.log.Timber
import java.io.File

class MainViewModel(
    private val application: Application,
    private val appPreferences: AppPreferences,
    private val autoPieConfigPathProvider: AutoPieConfigPathProvider,
    private val dispatchers: DispatcherProvider,
) : AndroidViewModel(application) {


    private val processManagerService: ProcessManagerService by inject(ProcessManagerService::class.java)
    private val useCases: AutoPieUseCases by inject(AutoPieUseCases::class.java)
    private val configBackupService = ConfigBackupService()
    private val dependencyRestore by lazy { RestoreCommandDependencies(processManagerService) }
    var restorePackagesOpen by mutableStateOf(false)
        private set
    var restorePackagesBusy by mutableStateOf(false)
        private set
    var restorePackagesMessage by mutableStateOf("")
        private set
    var restorePackagesPlan by mutableStateOf<DependencyRestorePlan?>(null)
        private set

    fun dismissRestorePackages() {
        if (!restorePackagesBusy) restorePackagesOpen = false
    }

    fun checkRestoredPackages() {
        if (restorePackagesBusy) return
        restorePackagesOpen = true
        restorePackagesBusy = true
        restorePackagesPlan = null
        restorePackagesMessage = "Updating catalog commands and checking packages…"
        viewModelScope.launch {
            try {
                val plan = withContext(dispatchers.io) {
                    check(AutoPieCoreService.fetchLatestRepositoryJson(forceRefresh = true)) {
                        "Could not refresh the command catalog. Check your connection and retry."
                    }
                    val catalog = useCases.getRepoCommandsList(AutoPieCoreService.repositoryJsonFile().absolutePath)
                    val configFile = autoPieConfigPathProvider.getConfigFile("commands.json")
                    val original = configFile.readText()
                    val commands = JsonParser.parseString(original).asJsonObject
                    val result = dependencyRestore.plan(commands, catalog.map { it.id }.toSet(), commandsRepositoryChannel)
                    result.refreshedCommands?.takeIf { it != commands }?.let { refreshed ->
                        check(configFile.readText() == original) { "Config changed during recipe lookup. Retry the check." }
                        val atomicFile = AtomicFile(configFile)
                        val output = atomicFile.startWrite()
                        try {
                            output.write(GsonBuilder().setPrettyPrinting().disableHtmlEscaping()
                                .create().toJson(refreshed).toByteArray(Charsets.UTF_8))
                            atomicFile.finishWrite(output)
                        } catch (error: Exception) {
                            atomicFile.failWrite(output)
                            throw error
                        }
                    }
                    result
                }
                emitEvent(ViewModelEvent.RefreshCommandsList)
                emitEvent(ViewModelEvent.CommandsConfigChanged)
                restorePackagesPlan = plan
                restorePackagesMessage = if (plan.missingCount == 0) {
                    "All identified dependencies are installed."
                } else {
                    "${plan.missingCount} missing packages can be installed."
                }
            } catch (error: CancellationException) {
                throw error
            } catch (error: Exception) {
                Timber.e(error)
                restorePackagesMessage = "Package check failed. Your config is still available. Check your connection and retry."
            } finally {
                restorePackagesBusy = false
            }
        }
    }

    fun installRestoredPackages() {
        val plan = restorePackagesPlan ?: return
        if (restorePackagesBusy || plan.missingCount == 0) return
        restorePackagesBusy = true
        restorePackagesMessage = "Preparing installation…"
        viewModelScope.launch {
            try {
                val opened = dependencyRestore.install(plan)
                restorePackagesPlan = null
                restorePackagesMessage = if (opened) {
                    "Installation opened in Termux. View the results there, then use Update commands / retry packages if needed."
                } else "All identified dependencies are already installed."
            } catch (error: CancellationException) {
                throw error
            } catch (error: Exception) {
                Timber.e(error)
                restorePackagesMessage = "Could not open installation in Termux. Retry to check and install missing packages."
            } finally {
                restorePackagesBusy = false
            }
        }
    }

    private val _eventFlow = MutableSharedFlow<ViewModelEvent>(replay = 0)
    val eventFlow = _eventFlow.asSharedFlow()

    var currentCommandKey = mutableStateOf("")
    var currentSelectedCommand = mutableStateOf<CommandModel?>(null)

    var viewModelError = MutableSharedFlow<Notification?>(replay = 0)
    var appNotification = MutableSharedFlow<Notification?>(replay = 0)


    var pythonInstallationComplete by mutableStateOf(false)

    var updatesAreAvailable : Boolean? by mutableStateOf(null)
    var packageUpdatesAreAvailable : Boolean? by mutableStateOf(null)

    var updateDetails: ReleaseInfo? by mutableStateOf(null)

    var commandsConfigAvailable by mutableStateOf(false)
    var observerConfigAvailable by mutableStateOf(false)
    var schedulerConfigAvailable by mutableStateOf(false)
    var mcpServerActive by mutableStateOf(false)

    var installInitPackagesPrompt by mutableStateOf(false)
    val initPackageCommandKeywords = listOf("ffmpeg", "yt-dlp", "imagemagick", "openssh", "rsync")
    private var initPackageCommandsPromptHandled by mutableStateOf(
        appPreferences.getBoolSync(AppPreferences.INIT_PACKAGE_COMMANDS_PROMPT_HANDLED)
    )

    //MOVED HERE FROM SHARERECEIVERVIEWMODEL becase of State Hoisting necessity
    var shareReceiverSearchQuery = mutableStateOf("")




    var turnOnFileObservers by mutableStateOf(appPreferences.getBoolSync(AppPreferences.IS_FILE_OBSERVERS_ON)).also { state ->
        viewModelScope.launch {
            appPreferences.getBool(AppPreferences.IS_FILE_OBSERVERS_ON).collectLatest{
                state.value = it
            }
        }
    }

    var autoPieConfigPath by mutableStateOf(autoPieConfigPathProvider.getAutoSecDirectory().absolutePath)
    var fileLoggerPath by mutableStateOf(autoPieConfigPathProvider.getLogFile().absolutePath)

    var autoPieConfigLocation by mutableStateOf(autoPieConfigPathProvider.getConfigLocationSync()).also { state ->
        viewModelScope.launch {
            autoPieConfigPathProvider.locationFlow.collectLatest {
                state.value = it
                autoPieConfigPath = autoPieConfigPathProvider.getAutoSecDirectory(it).absolutePath
                fileLoggerPath = autoPieConfigPathProvider.getLogFile().absolutePath
            }
        }
    }

    var fileLoggingEnabled by mutableStateOf(appPreferences.getBoolSync(AppPreferences.FILE_LOGGING_ENABLED, false)).also { state ->
        viewModelScope.launch {
            appPreferences.getBool(AppPreferences.FILE_LOGGING_ENABLED, false).collectLatest{
                state.value = it
            }
        }
    }

    var commandsRepositoryChannel by mutableStateOf(
        CommandsRepositoryChannel.fromPreference(
            appPreferences.getStringSync(AppPreferences.COMMANDS_REPOSITORY_CHANNEL)
        )
    )
        private set
    private var commandsRepositoryChannelUpdateJob: Job? = null

    var homeCommandPreview by mutableStateOf(
        HomeCommandPreview.fromPreference(
            appPreferences.getStringSync(AppPreferences.HOME_COMMAND_PREVIEW)
        )
    )
        private set

    var storageManagerPermissionGranted by mutableStateOf(if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        Environment.isExternalStorageManager()
    } else {
        application.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
                application.checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    })

    fun showNotification(notification: AppNotification){
        viewModelScope.launch {
            appNotification.emit(notification)
        }
    }

    fun showError(error: ViewModelError){
        Timber.e("Printing Error:")
        viewModelScope.launch {
            viewModelError.emit(error)
        }
    }

    fun toggleFileObservers(){
        viewModelScope.launch {
            if(appPreferences.getBoolSync(AppPreferences.IS_FILE_OBSERVERS_ON)){
                appPreferences.setBool(AppPreferences.IS_FILE_OBSERVERS_ON, false)
                cancelJob(application)
            }else{
                appPreferences.setBool(AppPreferences.IS_FILE_OBSERVERS_ON, true)
                scheduleJob(application)
            }
        }
    }

    fun updateAutoPieConfigLocation(location: AutoPieConfigLocation) {
        if (location == autoPieConfigLocation) {
            return
        }

        viewModelScope.launch(dispatchers.io) {
            val moved = autoPieConfigPathProvider.moveAutoSecDirectoryTo(location)
            if (!moved) {
                showError(ViewModelError.Unknown)
                return@launch
            }

            autoPieConfigPathProvider.setConfigLocation(location)
            AutoPieCoreService.initAutosec()
        }
    }

    fun updateFileLoggingEnabled(enabled: Boolean) {
        viewModelScope.launch {
            appPreferences.setBool(AppPreferences.FILE_LOGGING_ENABLED, enabled)
        }
    }

    fun updateCommandsRepositoryChannel(channel: CommandsRepositoryChannel) {
        if (channel == commandsRepositoryChannel) return

        commandsRepositoryChannel = channel
        commandsRepositoryChannelUpdateJob?.cancel()
        commandsRepositoryChannelUpdateJob = viewModelScope.launch(dispatchers.io) {
            appPreferences.setString(
                AppPreferences.COMMANDS_REPOSITORY_CHANNEL,
                channel.preferenceValue
            )
            AutoPieCoreService.fetchLatestRepositoryJson(forceRefresh = true)
        }
    }

    fun updateHomeCommandPreview(preview: HomeCommandPreview) {
        if (preview == homeCommandPreview) return

        homeCommandPreview = preview
        viewModelScope.launch(dispatchers.io) {
            appPreferences.setString(AppPreferences.HOME_COMMAND_PREVIEW, preview.preferenceValue)
        }
    }

    fun shouldPromptForInitPackageCommands(): Boolean =
        storageManagerPermissionGranted &&
            !initPackageCommandsPromptHandled

    fun markInitPackageCommandsPromptHandled() {
        initPackageCommandsPromptHandled = true
        viewModelScope.launch(dispatchers.io) {
            appPreferences.setBool(AppPreferences.INIT_PACKAGE_COMMANDS_PROMPT_HANDLED, true)
        }
    }

    fun installCloudCommandsForKeywords(keywords: List<String>) {
        val selectedKeywords = keywords.map(String::trim).filter(String::isNotBlank)
        if (!storageManagerPermissionGranted || initPackageCommandsPromptHandled) {
            return
        }

        initPackageCommandsPromptHandled = true

        viewModelScope.launch(dispatchers.io) {
            try {
                if (selectedKeywords.isEmpty()) {
                    appPreferences.setBool(AppPreferences.INIT_PACKAGE_COMMANDS_PROMPT_HANDLED, true)
                    return@launch
                }

                // Open the visible Termux install session before repository and manifest downloads.
                // The package install script does not depend on the command catalog being prepared.
                runKeywordInstallCommands(selectedKeywords)

                appPreferences.setBool(AppPreferences.INIT_PACKAGE_COMMANDS_PROMPT_HANDLED, true)
                AutoPieCoreService.fetchLatestRepositoryJson()
                val repoListPath = AutoPieCoreService.repositoryJsonFile().absolutePath
                val matchingCommands = useCases.getRepoCommandsList(repoListPath)
                    .filter { command -> command.matchesAnyCloudKeyword(selectedKeywords) }
                    .distinctBy { it.id }

                useCases.installCloudCommand.installAll(
                    commandIds = matchingCommands.map { it.id },
                    runInstallScripts = false
                )
                withContext(dispatchers.main) {
                    emitEvent(ViewModelEvent.RefreshCommandsList)
                    emitEvent(ViewModelEvent.CommandsConfigChanged)
                }
            } catch (e: ViewModelError) {
                showError(e)
            } catch (e: Exception) {
                Timber.e(e)
                showError(ViewModelError.Unknown)
            }
        }
    }

    private suspend fun runKeywordInstallCommands(keywords: List<String>) {
        val installCommand = keywordInstallScriptFor(keywords)
        if (installCommand.isBlank()) {
            return
        }

        val command = CommandModel(
            id = "autopie.keyword-init-packages.install",
            type = CommandType.SHARE,
            name = "Install selected init packages",
            path = "",
            exec = "bash",
            command = installCommand
        )

        processManagerService.runCommandInTermuxShell(
            commandObject = command,
            exec = "bash",
            command = installCommand,
            cwd = application.filesDir.absolutePath,
            commandExtraInputs = emptyList(),
            rawInput = "",
            processId = (1000..9999).random(),
            jobType = JobType.STANDALONE,
            usePython = false,
            isShellScript = true
        )
    }



    fun dispatchEvent(event: ViewModelEvent) {
        Timber.d("Event Fired: $event")
        viewModelScope.launch(dispatchers.main) {
            emitEvent(event)
        }


    }

    private suspend fun emitEvent(event: ViewModelEvent) {
        when (event) {
            is ViewModelEvent.CommandsConfigChanged -> {
                // Schedule here so adding the first observer also works after an empty job ended.
                if (appPreferences.getBool(AppPreferences.IS_FILE_OBSERVERS_ON).first()) {
                    scheduleJob(application)
                }
            }

            is ViewModelEvent.CreateShell -> withContext(dispatchers.io) {
                processManagerService.createShell(event.processId)
            }

            is ViewModelEvent.StopShell -> withContext(dispatchers.io) {
                processManagerService.stopShell(event.processId)
            }

            else -> {

            }
        }
        _eventFlow.emit(event)
    }

    fun clearAllBanners(){
        viewModelScope.launch {
            appNotification.emit(null)
            viewModelError.emit(null)
        }
    }

    fun clearPackagesCache(){
        viewModelScope.launch {
            processManagerService.clearPackagesCache()
            showNotification(AppNotification.ClearedPackageCache)
        }
    }

    fun backupCommandsConfig(destination: Uri) {
        viewModelScope.launch(dispatchers.io) {
            try {
                val output = application.contentResolver.openOutputStream(destination, "w")
                    ?: throw IllegalStateException("Could not open backup destination")
                output.use {
                    configBackupService.createBackup(
                        autoPieConfigPathProvider.getConfigFile("commands.json"),
                        it
                    )
                }
                showNotification(AppNotification.ConfigBackupCreated)
            } catch (error: Exception) {
                Timber.e(error, "Failed to back up commands config")
                showError(ViewModelError.ConfigBackupFailed)
            }
        }
    }

    fun restoreCommandsConfig(source: Uri) {
        viewModelScope.launch(dispatchers.io) {
            try {
                val input = application.contentResolver.openInputStream(source)
                    ?: throw IllegalStateException("Could not open config backup")
                input.use {
                    configBackupService.restoreBackup(
                        it,
                        autoPieConfigPathProvider.getConfigFile("commands.json")
                    )
                }
                emitEvent(ViewModelEvent.RefreshCommandsList)
                emitEvent(ViewModelEvent.CommandsConfigChanged)
                showNotification(AppNotification.ConfigBackupRestored)
                withContext(dispatchers.main) { checkRestoredPackages() }
            } catch (error: Exception) {
                Timber.e(error, "Failed to restore commands config")
                showError(ViewModelError.ConfigRestoreFailed)
            }
        }
    }

    fun editConfigFile() {
        viewModelScope.launch(dispatchers.io) {
            try {
                val configFile = autoPieConfigPathProvider.getConfigFile("commands.json")
                configFile.parentFile?.mkdirs()

                val command = CommandModel(
                    id = "autopie/edit-config-file",
                    type = CommandType.SHARE,
                    name = "Edit Config File",
                    path = autoPieConfigPathProvider.getAutoSecDirectory().absolutePath,
                    exec = "nano",
                    command = "nano ${configFile.absolutePath.shellQuote()}"
                )

                processManagerService.runCommandInTermuxShell(
                    commandObject = command,
                    exec = "nano",
                    command = command.command,
                    cwd = autoPieConfigPathProvider.getAutoSecDirectory().absolutePath,
                    commandExtraInputs = emptyList(),
                    rawInput = "",
                    processId = (1000..9999).random(),
                    jobType = JobType.STANDALONE,
                    usePython = false,
                    isShellScript = false
                )
            } catch (e: Exception) {
                Timber.e(e)
                showError(ViewModelError.Unknown)
            }
        }
    }

    fun openLogsFile() {
        viewModelScope.launch(dispatchers.io) {
            try {
                val logFile = autoPieConfigPathProvider.getLogFile()
                logFile.parentFile?.mkdirs()
                logFile.createNewFile()

                val command = CommandModel(
                    id = "autopie/open-logs-file",
                    type = CommandType.SHARE,
                    name = "Open Logs File",
                    path = autoPieConfigPathProvider.getLogsDirectory().absolutePath,
                    exec = "less",
                    command = "less +F ${logFile.absolutePath.shellQuote()}"
                )

                processManagerService.runCommandInTermuxShell(
                    commandObject = command,
                    exec = "less",
                    command = command.command,
                    cwd = autoPieConfigPathProvider.getLogsDirectory().absolutePath,
                    commandExtraInputs = emptyList(),
                    rawInput = "",
                    processId = (1000..9999).random(),
                    jobType = JobType.STANDALONE,
                    usePython = false,
                    isShellScript = false
                )
            } catch (e: Exception) {
                Timber.e(e)
                showError(ViewModelError.Unknown)
            }
        }
    }

    private fun scheduleJob(context: Context) {
        FileObserverScheduler.schedule(context)
    }

    private fun cancelJob(context: Context) {
        FileObserverScheduler.cancel(context)
    }


    fun startMCPServer(){

        val mcpPath = File(autoPieConfigPathProvider.getBinDirectory(), "mcp_server").absolutePath
        val modulePath = File(autoPieConfigPathProvider.getAutoSecDirectory(), "mcp_modules").absolutePath
        val host = "0.0.0.0"
        val port  = "8000"

        viewModelScope.launch(dispatchers.io){
            try {
                processManagerService.startMCPServer(mcpPath, modulePath, host, port)
            }
            catch (e: Exception){
                showNotification(AppNotification.MCPServerStartError)
                mcpServerActive = false
            }
        }

        mcpServerActive = true

        viewModelScope.launch {
            delay(1520L)
            showNotification(AppNotification.MCPServerStarted(host, port))
        }


    }

    fun stopMCPServer(){
        viewModelScope.launch(dispatchers.io){
            try {
                processManagerService.stopMCPServer()
                Timber.d("MCP Server Stopped")
                withContext(dispatchers.main) {
                    mcpServerActive = false
                    showNotification(AppNotification.MCPServerStopped)
                }
            }
            catch (e: Exception){

                showError(ViewModelError.Unknown)
            }
        }
        }

    fun checkForUpdates(){
        viewModelScope.launch(dispatchers.io){
            try {
                val latest = GithubApiService.getLatestRelease() ?: return@launch

                Timber.d(latest.toString())

                val tag_name = latest.tag_name.removePrefix("v")

                if(GithubApiService.compareVersions(tag_name, BuildConfig.VERSION_NAME) > 0){

                    Timber.d("Updates are available")

                    updatesAreAvailable = true

                    updateDetails = latest

                    GithubApiService.getAarch64ApkUrl(latest)?.let{
                        showNotification(AppNotification.UpdatesAvailable(url = it))
                    }

                }
                else{
                    Timber.d("No Updates are available")

                    updatesAreAvailable = false
                }
            }catch (e: Exception){
                Timber.e(e)
            }
        }
    }

    fun checkForPackageUpdates(){
        viewModelScope.launch(dispatchers.io){
            try {
                Timber.d("Checking for package updates")

                if(autoPieConfigPathProvider.usesExternalStorage() && !storageManagerPermissionGranted){
                    Timber.d("Storage permission not granted")

                    return@launch
                }

                val autoSecFolder = autoPieConfigPathProvider.getAutoSecDirectory()

                val installedVersionText = File(autoSecFolder, "version.txt").readText()

                val currentVersionText = AutoPieConstants.AUTOPIE_INIT_ARCHIVE_URL.split("/").takeLast(2).joinToString("/")

                Timber.d("installedVersionText: $installedVersionText , currentVersionText: $currentVersionText")

                delay(3000L)

                if(installedVersionText != currentVersionText) {
                    packageUpdatesAreAvailable = true
                    Timber.d("Package updates available")
                    showNotification(AppNotification.PackageUpdatesAvailable(url = AutoPieConstants.AUTOPIE_PACKAGE_UPDATES_README_URL))
                }else{
                    Timber.d("No package updates available")
                    packageUpdatesAreAvailable = false
                }


            }catch (e: Exception){
                Timber.e(e)
            }
        }
    }



}

internal fun CloudCommandModel.matchesAnyCloudKeyword(keywords: List<String>): Boolean =
    keywords.any { keyword ->
        id.contains(keyword, ignoreCase = true) ||
            name.contains(keyword, ignoreCase = true) ||
            namespace.contains(keyword, ignoreCase = true) ||
            summary.contains(keyword, ignoreCase = true) ||
            tags.any { tag -> tag.contains(keyword, ignoreCase = true) }
    }

internal fun keywordInstallScriptFor(keywords: List<String>): String {
    val installCommands = keywords
        .map { keyword -> keyword.trim().lowercase() }
        .mapNotNull { keyword -> KEYWORD_INSTALL_COMMANDS[keyword] }
        .distinct()

    if (installCommands.isEmpty()) {
        return ""
    }

    return buildString {
        append(KEYWORD_INSTALL_HELPERS)
        append("\n\n")
        append(installCommands.joinToString(separator = "\n"))
        append('\n')
    }
}

private val KEYWORD_INSTALL_COMMANDS = linkedMapOf(
    "ffmpeg" to "autopie_pkg_install_once ffmpeg",
    "yt-dlp" to "autopie_pip_install_once yt-dlp",
    "imagemagick" to "autopie_pkg_install_once imagemagick",
    "openssh" to "autopie_pkg_install_once openssh",
    "rsync" to "autopie_pkg_install_once rsync"
)

private val KEYWORD_INSTALL_HELPERS = """
autopie_pkg_install_once() {
    local package="${'$'}1"

    if dpkg -s "${'$'}package" >/dev/null 2>&1; then
        printf '%s\n' "Package already installed: ${'$'}package"
        return
    fi

    pkg install -y "${'$'}package"
}

autopie_pip_install_once() {
    local package="${'$'}1"

    if pip show "${'$'}package" >/dev/null 2>&1; then
        printf '%s\n' "Python package already installed: ${'$'}package"
        return
    fi

    pip install "${'$'}package"
}
""".trimIndent()

private fun String.shellQuote(): String {
    return "'${replace("'", "'\\''")}'"
}
