# AutoPie patches for Termux

These patches contain the AutoPie-specific changes that previously lived as
commits in the `termux-app` submodule fork. They are applied in filename order
by `scripts/prepare-termux-app.sh`.

The series was rebased and verified against official Termux commit
`401bbe54b8f4e68302b1ff70678015a24628fb1d` on 2026-06-22.

The preparation script uses the latest official `master` by default. Pin a
specific revision or use another repository when needed:

```sh
TERMUX_REF=401bbe54b8f4e68302b1ff70678015a24628fb1d \
  ./build_with_termux.sh :app:assembleRelease

TERMUX_REPO=https://github.com/example/termux-app.git TERMUX_REF=my-branch \
  ./scripts/prepare-termux-app.sh
```

If upstream changes conflict with a patch, preparation stops before replacing
the existing generated `termux-app` directory.

Patch 18 embeds the Termux app module as a library and disables its upstream
bootstrap download and native bootstrap build. AutoPie supplies its own
`app/src/main/assets/bootstrap-aarch64.zip`. The native builds in the
`terminal-emulator` and `termux-shared` modules remain enabled because those
libraries are runtime dependencies, not bootstrap packaging scripts.

Patch 19 restores a standalone Gradle task named `downloadAutoPieBootstrap`.
The task downloads Termux's pinned bootstrap archive into the prepared Termux
source without wiring it back into the Termux library build. AutoPie then
patches and copies that archive with `scripts/prepare-termux-bootstrap.sh`.

Patch 20 adds the official Gradle distribution checksum to Termux's wrapper so
the generated source does not trigger F-Droid's missing checksum warning.

Patch 21 recognizes `login` as a supported login shell binary and preserves the
configured `LD_PRELOAD` value when constructing the Termux shell environment.

Patch 22 makes `RunCommandService` internal to AutoPie and removes Termux's
package-scoped `RUN_COMMAND` permission declaration. AutoPie invokes the service
with an explicit in-process intent, so separate package variants can coexist
without attempting to own the same permission.

Patch 24 derives shell `HOME` from the current app context's files directory,
matching runtime `PREFIX` for custom package builds and secondary Android users.
It also aligns home working-directory aliases with `HOME` before constructing
the shell environment so Bash shows `~` immediately on startup.

Patch 25 runs the APK's dpkg migration helper during shell environment setup,
including app startup and bootstrap completion. It repairs older prefixes
before package operations can overwrite the wrapper again. Package-manager
locks defer migration; missing bootstraps are skipped until installation ends.
